/**
 * Copyright 2015 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var express = require('express'); // app server
var bodyParser = require('body-parser'); // parser for post requests
const request = require('request-promise');

var app = express();

// Bootstrap application settings
app.use(express.static('./public')); // load UI from public folder
app.use(bodyParser.json());

var newContext = {
  global : {
    system : {
      //user_id:"my_user_id",
    }
  }
};

// Endpoint to be call from the client side
app.post('/api/message', function (req, res) {
  var assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
  if (!assistantId || assistantId === '<assistant-id>>') {
    return res.json({
      'output': {
        'text': 'The app has not been configured with a <b>ASSISTANT_ID</b> environment variable. Please refer to the ' + '<a href="https://github.com/watson-developer-cloud/assistant-simple">README</a> documentation on how to set this variable. <br>' + 'Once a workspace has been defined the intents may be imported from ' + '<a href="https://github.com/watson-developer-cloud/assistant-simple/blob/master/training/car_workspace.json">here</a> in order to get a working application.'
      }
    });
  }
  var contextWithAcc = (req.body.context) ? req.body.context : newContext;

  if (req.body.context) {
    contextWithAcc.global.system.turn_count += 1;
  }

  var textIn = '';

  if(req.body.input) {
    textIn = req.body.input.text;
  }

  var payload = {
    input: {
      message_type : 'text',
      text : textIn,
      options : {
        return_context : true
      }
    },
    context: contextWithAcc
  };

  //console.log('session '+req.body.session_id);
  //console.log('assistant Id '+process.env.ASSISTANT_ID);
  console.log('payload '+JSON.stringify(payload));
  return new Promise((resolve,reject) => 
    {
        try
        {
            var url=process.env.URL+process.env.ASSISTANT_ID+'/sessions/'+req.body.session_id+'/message?version='+process.env.VERSION_DATE;
            request.post({ 
                url: url,
                method: 'POST',
                proxy: process.env.PROXY,
                headers: {
                  // Specify headers, If any
                  "Authorization": "Basic " + new Buffer(process.env.ASSISTANT_USERNAME + ':' + process.env.ASSISTANT_IAM_APIKEY).toString('base64'),
                  "Content-Type": "application/json"
                  },
                  body: JSON.stringify(payload),
                  
              }, function(error, response, body){
                if(error) {
                    console.log(error);
                    reject(res.status(error.code || 500).json(error));
                } else {
                  console.log(body);
                  resolve(res.send(body));
                }
            });
          }
          catch(error) 
          {
              reject(error);
          }
      });
});

app.get('/api/session', function (req, res) {
  return new Promise((resolve,reject) => 
    {
        try
        {
            var url=process.env.URL+process.env.ASSISTANT_ID+'/sessions?version='+process.env.VERSION_DATE;
            request({ 
                url: url,
                method: 'POST',
                proxy: process.env.PROXY,
                headers: {
                  // Specify headers, If any
                  "Authorization": "Basic " + new Buffer(process.env.ASSISTANT_USERNAME + ':' + process.env.ASSISTANT_IAM_APIKEY).toString('base64')
                },
                
              }, function(error, response, body){
                if(error) {
                    console.log(error);
                    reject(res.send(error));
                } else {
                  console.log(response.statusCode, body);
                  resolve(res.send(body));
                }
            });
          }
          catch(error) 
          {
              reject(error);
          }
      });
});


module.exports = app;

