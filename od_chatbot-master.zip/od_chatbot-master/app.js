/**
 * Copyright 2015 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var express = require('express'); // app server
var bodyParser = require('body-parser'); // parser for post requests
var AssistantV2 = require('watson-developer-cloud/assistant/v2'); // watson sdk
var https = require('https');
//const tunnel = require('tunnel');
var HttpsProxyAgent = require('https-proxy-agent');
var agent = new HttpsProxyAgent('http://na9-s500-1:8080');

var app = express();

// Bootstrap application settings
app.use(express.static('./public')); // load UI from public folder
app.use(bodyParser.json());

// Create the service wrapper

var assistant = new AssistantV2({
  version: '2018-11-08',
  iam_apikey: process.env.ASSISTANT_IAM_APIKEY || '<iam_apikey>',
  url: process.env.ASSISTANT_URL || 'https://gateway.watsonplatform.net/assistant/api/',
});

var newContext = {
  global : {
    system : {
      user_id:"D-Wjsoo2Rd7d_uSb-jMUdb0U7gQvNpSR0xdP4C4C23je",
    }
  },
  skills: {
    "main skill": {
       user_defined: {
         account_number:"123456"
        }
     }
  }
};

// Endpoint to be call from the client side
app.post('/api/message', function (req, res) {
  var username="apikey";
  var passw=process.env.ASSISTANT_IAM_APIKEY;
  var assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
  if (!assistantId || assistantId === '<assistant-id>>') {
    return res.json({
      'output': {
        'text': 'The app has not been configured with a <b>ASSISTANT_ID</b> environment variable. Please refer to the ' + '<a href="https://github.com/watson-developer-cloud/assistant-simple">README</a> documentation on how to set this variable. <br>' + 'Once a workspace has been defined the intents may be imported from ' + '<a href="https://github.com/watson-developer-cloud/assistant-simple/blob/master/training/car_workspace.json">here</a> in order to get a working application.'
      }
    });
  }
  var contextWithAcc = (req.body.context) ? req.body.context : newContext;

  if (req.body.context) {
    contextWithAcc.global.system.turn_count += 1;
  }

  //console.log(JSON.stringify(contextWithAcc, null, 2));

  var textIn = '';

  if(req.body.input) {
    textIn = req.body.input.text;
  }

  var payload = {
    input: {
      message_type : 'text',
      text : textIn,
      options : {
        return_context : true
      }
    },
    context: contextWithAcc
  };

  //console.log('session '+req.body.session_id);
  //console.log('assistant Id '+process.env.ASSISTANT_ID);
  console.log('payload '+JSON.stringify(payload));
  return new Promise((resolve,reject) => 
    {
        try
        {
          /*let output = '';
            https.request({
              host: 'gateway.watsonplatform.net',
              port: 443,
              method: 'POST',
              path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions/'+req.body.session_id+'/message?version=2019-02-28',
              headers: {
                "Authorization": "Basic " + new Buffer(username + ':' + passw).toString('base64'),
                "Content-Type": "application/json",
                
                },
                //body: JSON.stringify(payload),
              /*  body:payload,
                agent: agent,
            
            }, function (resp) {
              //console.log(resp);
              resp.on('data', function (data) {
                console.log("resp");
                console.log(data.toString());
                output+=data;
                //resolve(res.send(data.toString()));
                });
                resp.on('end', function() {
                  //console.log("resp");
                  console.log(output.toString());
                  console.log(JSON.parse(output).explanation);
                  resolve(res.send(output.toString()));
                  })
            }).end();*/

            var options = {
              host: 'gateway.watsonplatform.net',
              port: 443,
              method: 'POST',
              path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions/'+req.body.session_id+'/message?version=2019-02-28',
              headers: {
                "Authorization": "Basic " + new Buffer(process.env.ASSISTANT_USERNAME + ':' + process.env.ASSISTANT_IAM_APIKEY).toString('base64'),
                "Content-Type": "application/json",
              },
              agent: agent
            };

            let data = "";
            let apiRequest = https.request(options, function(result) {
              console.log("Connected--1"+result);
              result.on("data", chunk => {
                data += chunk;
              });
              result.on("end", () => {
                console.log("data collected"+data.toString());
                resolve(res.send(data.toString()));
                //res.end(JSON.stringify(data));
              });
            });
          
            apiRequest.end();

          }
          catch(error) 
          {
              reject(error);
          }
      });
});

app.get('/api/session', function (req, res) {
  return new Promise((resolve,reject) => 
    {
        try
        {
            /*https.request({
              // like you'd do it usually...
              host: 'gateway.watsonplatform.net',
              port: 443,
              method: 'POST',
              path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions?version=2019-02-28',
              headers: {
                "Authorization": "Basic " + new Buffer(username + ':' + passw).toString('base64'),
                "Content-Type": "application/json",
                },
             agent: agent
            }, function (resp) {
                  resp.on('data', function (data) {
                  console.log(data.toString());
                  resolve(res.send(data.toString()));
            });
            }).end();*/

           // let url = process.env.URL+process.env.ASSISTANT_ID+'/sessions?version='+process.env.VERSION_DATE;
            var options = {
              host: 'gateway.watsonplatform.net',
              port: 443,
              method: 'POST',
              path: '/conversation/api/v2/assistants/'+process.env.ASSISTANT_ID+'/sessions?version=2019-02-28',
              headers: {
                "Authorization": "Basic " + new Buffer(process.env.ASSISTANT_USERNAME + ':' + process.env.ASSISTANT_IAM_APIKEY).toString('base64'),
                "Content-Type": "application/json",
              },
              agent: agent
            };

            let data = "";
            let apiRequest = https.request(options, function(result) {
              console.log("Connected");
              result.on("data", chunk => {
                data += chunk;
              });
              result.on("end", () => {
                console.log("data collected"+data.toString());
                resolve(res.send(data.toString()));
                //res.end(JSON.stringify(data));
              });
            });
            apiRequest.end();
          }
          catch(error) 
          {
              reject(error);
          }
      });
});


module.exports = app;
//module.exports = logger;
