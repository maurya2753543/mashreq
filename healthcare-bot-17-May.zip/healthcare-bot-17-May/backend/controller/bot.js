const { response } = require('express');
var AssistantV2 = require('ibm-watson/assistant/v2'); // watson sdk
const { IamAuthenticator, BearerTokenAuthenticator } = require('ibm-watson/auth');
require('dotenv').config({silent: true});
const axios = require('axios')
let authenticator;
console.log(process.env.ASSISTANT_IAM_APIKEY,'plp')
if (process.env.ASSISTANT_IAM_APIKEY) {
  authenticator = new IamAuthenticator({
    apikey: process.env.ASSISTANT_IAM_APIKEY
  });
} else if (process.env.BEARER_TOKEN) {
  authenticator = new BearerTokenAuthenticator({
    bearerToken: process.env.BEARER_TOKEN
  });
}

var assistant = new AssistantV2({
  version: '2020-12-23',
  authenticator: authenticator,
  url: process.env.ASSISTANT_URL,
  disableSslVerification: true
});

module.exports={
    SendMessage,
    createSession

}

async function SendMessage(req,res)
{
try {
  console.log('message>>>>>>>>>',req.body,'messahe')
    let assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
    if (!assistantId || assistantId === '<assistant-id>') {
      return res.json({
        output: {
          text: "Error"

        }
      });
    }

    var textIn = '';

    if (req.body.message) {
      textIn = req.body.message;
    }

    var payload = {
      assistantId: assistantId,
      sessionId: req.body.session_id,
      input: {
        message_type: 'text',
        text: textIn,
      },
    };
    

    let data = await WatsonMessageHelper(payload)
    console.log(payload,'req.body.type')
    
if(req.body.type=='query'){
  let splitted_data=data.result.output.generic[0].text.split('/n')
  console.log(splitted_data,'lop')
  combined_data=[]
   combined_data.push({response_type:"text",type:"",text:splitted_data[0]+'<strong>'+ req.body.data+'</strong>' + splitted_data[1]})
   combined_data.push(data.result.output.generic[1])
   console.log(combined_data)
  // console.log(splitted_data,data.result.output.generic,'in the splitted value')
  return res.json(combined_data)


}

 
  else{
    data.result.output.generic[0].type=""

    return res.json(data.result.output.generic)
  }
}
  catch (e) {
    console.log(e,'error+error')
    return res.json({code:404,message:"Message Error"})

      // return res.status(status).json(e);

    
  }

}

async function createSession(req,res){
  try{
    let response= await session()
    console.log(response,'response')
    return res.json({status:200,data:response.result})
  }
  catch(e){
    return res.json({status:404,message:"Error creating the session"})
  }
}

        async function session() {

            return new Promise((resolve,reject)=>{
              assistant.createSession(
                {
                  assistantId: process.env.ASSISTANT_ID || '{assistant_id}',
                },
                function (error, response) {
                  if (error) {
                    console.log(error, 'error')
                    // return res.send(error);
                    reject(err)
                  } else {
                    // console.log(response.result.session_id,'sesionid__response+++++++')
                    // return res.send(response);
                    resolve(response)
                  }
                }
              )
            })
            
          }

          async function WatsonMessageHelper(payload) {

            return new Promise((resolve, reject) => {
          
              try {
                assistant.message(payload, async function (err, data) {
          
          
                  if (err) {
                    const status = err.code !== undefined && err.code > 0 ? err.code : 500;
                    // return res.status(status).json(err);
                    if (err.message == "Invalid Session") {
          
                      let response = await session()
                      console.log(response,'response+sessionid')
                      payload.sessionId = response.result.session_id
          console.log(payload,'payload value')
                     let data=await WatsonMessageHelper(payload)
                       resolve(data)
                    }
          
                  }
                  else {
          
                    console.log(data,'sendmessagetowatson')
                    resolve(data);
                  }
          
                })
              }
              catch (e) {
                reject(e)
              }
          
            })
          }