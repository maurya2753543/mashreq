[
    { "UserID": "mrinal.singh@hcl.com", "password": "MRINAL", "UserName": "Mrinal Singh", "Code": "USAA0001", "Admin": true },
    { "UserID": "ruchi.bisht@hcl.com", "password": "RB", "UserName": "Ruchi Bisht", "Code": "USAA0001", "Admin": true }

]
