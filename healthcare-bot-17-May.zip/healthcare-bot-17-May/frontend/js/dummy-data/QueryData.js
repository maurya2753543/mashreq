{
    "dataSet" : [
        ["Nilisha", "nilisha.gupta@hcl.com", "999988770", "1"],
        ["Mrinal", "mrinal.singh@hcl.com", "898876544", "2"],
        ["Manish", "manish.seth@hcl.com", "9876667789", "3"],
        ["Ruchi", "ruchi.bisht@hcl.com", "9987654322", "4"]

    ],

    "ColumnHeading" :
        [
            { "title": "Name", "sTitle": "Name" },
            { "title": "Email Id", "sTitle": "Email Id" },
            { "title": "Phone Number", "sTitle": "Phone Number" },
            { "title": "User ID", "sTitle": "User ID" }

        ]
}
