
var globalVariable = "";
var globalqueryarray=[]
var i = 1;
$(function () {
    $("#btnShowPopup").click(function () {
        var title = "Healthcare Bot";
        // var body = "Welcome to ASPSnippets.com";

        $("#MyPopup .modal-title").html(title);
        // $("#MyPopup .modal-body").html(body);
        $("#MyPopup").modal("show");
        $(".chat_box").css("right", "10px");

        (function ($) {
            $.ajax({
                url: 'http://localhost:3000/api/session',
                type: 'Get',
                success: function (result) {
                    sessionStorage.setItem('Sessionid', result.data.session_id)
                    send_msg('1')
                }
            })
        })($)
    });
    $(".modal").on("hidden.bs.modal", function () {
        $(".messages-list").html("");
        // $("#input-me").attr("autocomplete", "off");

    });
    $(".close").click(function () {
        globalVariable = "";
        globalqueryarray=[]
        $(".chat_box").css("right", "-360px");
        $('#input-me').val('')
        $(".messages-list").html("");

    })
    setInterval(function () {
        $(".chat_icon").css("animation", "shake-chat-icon");
    }, 500);
});
$('#input-me').keypress(function (e) {
    if (e.which == 13) {
        $('#click-me').click();
    }
});
function sendMessageToWatson(options,type,text) {
    var htm2 = '<div id="ok" style="margin-left:-14px" class="typing-indicator"><li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/OIP.jfif"></span>Typing...<span></span<span></span></p></li></div>'
    $('.messages-list').append(htm2)
    $.ajax({
        url: 'http://localhost:3000/api/message',
        type: 'Post',
        data: { session_id: sessionStorage.getItem('Sessionid'), message: text ,data:options,type:type},
        success: function (result) {
            if (result && result[0].type &&result[0].type == 'query') {
                $('#ok').remove();

                result.forEach(element => {
                    if(element.response_type == "text"){

                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.text +'</span><div class="message-header"></div></p></li>'

                        $('.messages-list').append(html)

                    }

                    if(element.response_type == "option"){
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.title +'</span><div class="message-header"></div></p></li>'

                        $('.messages-list').append(html)
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                });
                globalVariable = 'query'
                console.log('global variable ',globalVariable)
                // raiseQuery()

            }
           
            else{
                result.forEach(element => {
                    $('#ok').remove();
                    if(element.response_type == "text"){
                    var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/OIP.jfif"></span><span class="messages-bot">' + element.text +'</span><div class="message-header"></div></p></li>'
                     $('.messages-list').append(html)
                    }
                    if(element.response_type == "option"){
                        console.log(element.title,'element.title in query')
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/OIP.jfif"></span><span class="messages-bot">' + element.title +'</p></li>'
                        $('.messages-list').append(html)

                        element.options.forEach((innerele)=>{
                            console.log(innerele.value.input.text,'innerele.label+label')
                            var html1 ='<li  class="msg-bot clearfix"><div class="col-sm-6 message-header"><input type="button" id="no'+i+'" style="margin-left: 4px; margin-top: 3px" class="btn btn-primary" value="'+innerele.label+'" onclick="callNo('+i+')">'+'</div></li>'
                            $('.messages-list').append(html1)
                            i++
                        })
                      
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                    // $('.messages-box').scrollTop($('.messages-box')[0].scrollHeight);
                });
                i++

            }
        }
    })
}

function send_msg(defaultInput) {
    console.log(globalVariable,'window.globalVariable')
    var text = $('#input-me').val()
    console.log(text, 'inputvalue')
    if (/^\s*$/.test(text) &&  defaultInput == '2') {
        return;
      }
    if (text == '') {
        // return
        sendMessageToWatson('','','')
    }
    else {
        $('.list-unstyled').animate({
            scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");


        if (text) {

            var html = '<li class="msg-user clearfix"><p><span class="messages-user-icon"></span><span class="messages-user">' + text +'</span><div class= "message-header"></div></p></li>'
            // var html = '<li class="messages-me clearfix"><div class= "message-header"><strong class="messages-title">Me</strong><small class="text-messages text-muted"></small></div><p class="messages-p">'+text+'</p>'

            $('.messages-list').append(html)
            $('#input-me').val('')
            
            if (globalVariable == 'query') {
                raiseQuery(text)
                // sendMessageToWatson('query')
            }
            else{

            sendMessageToWatson('','',text)
           
            }
        }
    }

}



// function callNo(i) {
//     $('.list-unstyled').animate({
//         scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
//     // console.log('iiiiiiii', i)
//     // $("#yes" +i ).attr("disabled",true)
//     // $("#no" +i).attr("disabled",true)

//     // var value = $('#no'+i).val()
//     // console.log(value)
//     // sendMessageToWatson('', 'another query', value)
//     var value = $('#no').val()
//     if(value == "No"){
//         var text = "no"
//     }
//     sendMessageToWatson('', '', text)

// }
function callNo(i) {
    // $("#yes" +i ).attr("disabled",true)
    // $("#no" +i).attr("disabled",true)
     console.log('i>>>>>>',i)
    var value = $('#no'+i).val()
    console.log(value)
    // if(value == 'Other')
    // window.open('https://healthyhcl.in/assets/mailer/COVID%20Vaccination%20-%20Information%20Flyer_HCLH.pdf', '_blank');
     if(value == 'https://healthyhcl.in/assets/mailer/English%20FAQ%20on%2018+%20Vaccination_210507_132400.pdf'){
             window.open(value, '_blank');
        return;
     }
     if(value == 'https://healthyhcl.in/assets/mailer/COVID%20Vaccination%20-%20Information%20Flyer_HCLH.pdf'){
             window.open(value, '_blank');
        return;
     }
     if(value == 'https://healthyhcl.in/assets/mailer/COVID-%20Dos%20&%20Donts%20Poster%20-%202%20x%203%20ft-V5.pdf'){
             window.open(value, '_blank');
        return;
     }


    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
    var html = '<li class="msg-user clearfix"><p><span class="messages-user-icon"></span><span class="messages-user">' + value +'</span><div class= "message-header"></div></p></li>'
    // var html = '<li class="messages-me clearfix"><div class= "message-header"><strong class="messages-title">Me</strong><small class="text-messages text-muted"></small></div><p class="messages-p">'+text+'</p>'

    $('.messages-list').append(html)
    $('#input-me').val('')
    sendMessageToWatson('', '', value)

}

