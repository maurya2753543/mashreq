import { Component, OnInit } from '@angular/core';
import { localStorageVariables, resetLocalStorage, appVariables, appSessionErr, appGenericErr, snackBarDuration } from 'src/app/app.constants';
import { SessionService } from '../../Views/session/session.service';
import { AppLoaderService } from '../services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-header-top',
  templateUrl: './header-top.component.html',
  styleUrls: ['./header-top.component.scss']
})
export class HeaderTopComponent implements OnInit {

  public userInfo;

  constructor(
    private sessionService: SessionService,
    private loader: AppLoaderService,
    private router: Router,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));
  }

  logout(){
    this.loader.open();
    this.sessionService.logout()
    .subscribe( res => {
      this.loader.close();
      resetLocalStorage();
      this.router.navigate([appVariables.loginPageUrl]);
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration}); 
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      } 
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
      this.loader.close();
    })
  }

}
