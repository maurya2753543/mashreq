import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SharedService } from '../../shared/shared.service';
import { BaseService } from '../../shared/services/base.service';
import { appApiPaths } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(
    private sharedService: SharedService,
    private baseService: BaseService
  ) { }

  getQuestionBank(subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestionBank+subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getRawDataReport(fromDate, toDate): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getRawDataReport + fromDate +'&endDate=' + toDate, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getUserAssessmentReport(assessmentId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getUserAssessmentReport + assessmentId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              }else if(res.status == 204){
                return null;
              } else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getQuestionReport(name, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestionReport + name + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getUserReport(lobId, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getUserReport + lobId + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAssessmentName(fromDate, toDate, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAssessmentNameForUserReport+fromDate+'&endDate='+toDate + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAllLob(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllLob , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getSubLob(lobName): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getSubLob + lobName , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }
  getSummaryDataReport(fromDate, toDate): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getSummaryReport + fromDate +'&endDate=' + toDate, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getCategoryWiseAIReport(fromDate, toDate, lobId, subLobId?:any): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getCategoryWiseAIReport + fromDate +'&endDate=' + toDate + '&lobId=' + lobId;
    if(subLobId){
      url = url + '&subLobId=' + subLobId;
    }else {
      url = url + '&subLobId=' + 0;
    }
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getLowScoreWiseAIReport(lobId, subLobId?:any): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getLowScoreWiseAIReport + lobId;
    if(subLobId){
      url = url + '&subLobId=' + subLobId;
    }else {
      url = url + '&subLobId=' + 0;
    }
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getHighScoreWiseAIReport(lobId, subLobId?:any): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getHighScoreWiseAIReport + lobId;
    if(subLobId){
      url = url + '&subLobId=' + subLobId;
    }else {
      url = url + '&subLobId=' + 0;
    }
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getQuestionWiseAIReport(fromDate, toDate, assessmentId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getQuestionWiseAIReport + fromDate + '&endDate=' + toDate + '&assessmentId=' + assessmentId;
    
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getEmployeeWiseSummaryAlReport(lobId, sapId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getEmployeeWiseSummaryAlReport + lobId + '&sapId=' + sapId;
    
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getEmployeeWiseAlReport(lobId, sapId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getEmployeeWiseAlReport + lobId + '&sapId=' + sapId;
    
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAllCategory(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllCategory, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }
}
