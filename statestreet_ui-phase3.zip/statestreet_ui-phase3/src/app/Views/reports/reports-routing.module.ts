import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReportsComponent } from './reports.component';
import { AdminReportComponent } from './admin-report/admin-report.component';
import { AiReportComponent } from './ai-report/ai-report.component';

const routes: Routes = [
  { path: '', component: ReportsComponent },
  { path: 'admin', component: AdminReportComponent },
  { path: 'ai', component: AiReportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
