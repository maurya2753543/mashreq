import { Component, OnInit, ViewChild } from '@angular/core';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { ReportService } from '../report.service';
import { MatSnackBar, MatTabGroup } from '@angular/material';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { appGenericErr, snackBarDuration, appVariables, resetLocalStorage, appSessionErr, digitPattern } from '../../../app.constants';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-ai-report',
  templateUrl: './ai-report.component.html',
  styleUrls: ['./ai-report.component.scss']
})
export class AiReportComponent implements OnInit {

  @ViewChild('tabGroup', { static: false }) private tabGroup: MatTabGroup;

  public reportList = ['Question Category Specific Reports', 
                      'Frequent Low Scorer Report',
                      'Frequent High Scorer Report', 
                      'Question Wise Analysis Report', 
                      'Detailed Employee Report'];
  public employeeLagOnCategoryReport = null;
  public employeeFailingWithLowerScore = [];
  public employeePassingWithHigherScore = [];
  public questionWiseAnalysisReport = [];
  public employeeWiseDetailedReport = [];
  // public employeeWiseDetailedReport = test;
  public employeeWiseSummaryReport = null;
  public reportForm:FormGroup;
  public currentPage = 1;
  public itemsPerPage = 6;
  public lobConfig;
  public subLobConfig;
  public lobList = [];
  public subLobList = [];
  public assessmentList = [];
  public assessmentConfig;
  public minDate:Date;
  public maxDate:Date;
  public showReport = false;
  public categoryList = [];
  public categoryLagList = [];

  constructor(
    private loader: AppLoaderService,
    private reportService: ReportService,
    private snackBar: MatSnackBar,
    private router: Router,
    private fb: FormBuilder
  ) { 
    const currentYear = new Date().getFullYear();
    this.minDate = new Date(currentYear - 20, 0, 1);
    this.maxDate = new Date();
    this.lobConfig = {
      displayKey:"lobName",
      search:true,
      height: '200px',
      placeholder:'Select',
      customComparator: ()=>{},
      limitTo: this.lobList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      displayKey:"subLobName",
      search:true,
      height: '200px',
      placeholder:'Select',
      customComparator: ()=>{},
      limitTo: this.subLobList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'subLobName'
    }
    this.assessmentConfig = {
      displayKey:"assessmentName",
      search:true,
      height: '200px',
      placeholder:'Select',
      customComparator: ()=>{},
      limitTo: this.assessmentList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'assessmentName'
      }
  }

  ngOnInit() {
    this.getAllCategory();
    this.getAllLob();
    this.createReportForm();
  }

  createReportForm(){
    this.reportForm = this.fb.group({
      reportType: ['', Validators.required],
      fromDate: [{value: '', disabled: false}, Validators.required],
      toDate: [{value: '', disabled: false}, Validators.required],
      lob: [null, Validators.required],
      subLob : [null],
      assessment: [null],
      sapId: ['']
    })
  }

  catData(data){
    let catList = [];
    this.categoryList.forEach(category => {
      let obj = {
        category: category.categoryName,
        score: 0
      }
      catList.push(obj);
    })
    catList.forEach(cat => {
      data.forEach(score => {
        if(score.category == cat.category){
          cat.score = score.questionResult;
        }
      })
    })
    return catList;
  }

  catSummaryData(data){
    let catList = [];
    this.categoryList.forEach(category => {
      let obj = {
        category: category.categoryName,
        score: 0
      }
      catList.push(obj);
    })
    catList.forEach(cat => {
      data.forEach(score => {
        if(score.category == cat.category){
          cat.score = score.successPercentage;
        }
      })
      cat.category = cat.category + ' Success Percent'
    })
    return catList;
  }

  getAllCategory(){
    this.loader.open();
    this.reportService.getAllCategory()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.categoryList = this.removeSpecialCharacterFromStr(res);
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('No Category Found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  removeSpecialCharacterFromStr(res){
    let strArr = res;
    strArr.forEach(obj => {
      if (obj.categoryName.indexOf('_') > -1){
        let s = obj.categoryName.replace(/_/g, ' ');
        obj.categoryName = s;
      }
    })
    return strArr;
  }

  getAllLob(){
    this.loader.open();
    this.reportService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.lobList = res;
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getSubLobList(){
    this.loader.open();
    this.reportForm.get('subLob').setValue([]);
    this.reportForm.get('assessment').setValue([]);
    this.subLobList = [];
    this.clearReportOnSelectionChange();
    if(this.reportForm.get('lob').value){
      this.reportService.getSubLob(this.reportForm.get('lob').value.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        } else if(err.status == '404'){
          this.snackBar.open('No Sub Lob found for selected LOB', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
    
  }

  getAssessmentList(){
    this.loader.open();
    this.assessmentList = [];
    this.reportForm.get('assessment').setValue([]);
    this.clearReportOnSelectionChange();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
    if(this.validateDate() && this.reportForm.get('subLob').value){
      this.reportService.getAssessmentName(fromDate, toDate, this.reportForm.get('subLob').value.subLobId)
    .subscribe(res => {
      this.loader.close();
      this.reportForm.get('assessment').setValidators(Validators.required);
      this.reportForm.get('assessment').updateValueAndValidity();

      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.snackBar.open('No Assessment available for selected date range and Sub-LOB', 'OK', {duration: snackBarDuration});
      }
      else{
        this.assessmentList = res;
        this.assessmentConfig.limitTo = this.assessmentList.length;
      }
    },err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        this.snackBar.open('Invalid Data!', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
    }else{
      this.loader.close();
    }
  }

  initialValidation(){
    this.reportForm.get('fromDate').setValidators(Validators.required);
    this.reportForm.get('toDate').setValidators(Validators.required);
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').clearValidators();
    this.reportForm.get('sapId').clearValidators();
    this.reportForm.get('assessment').clearValidators();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('assessment').updateValueAndValidity();
    this.reportForm.get('sapId').updateValueAndValidity();
  }

  toggleValidationForQuestionWiseAIReport(){
    this.reportForm.get('fromDate').setValidators(Validators.required);
    this.reportForm.get('toDate').setValidators(Validators.required);
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').setValidators(Validators.required);
    this.reportForm.get('sapId').clearValidators();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('sapId').updateValueAndValidity();
  }

  toggleValidationForClearDate(){
    this.reportForm.get('fromDate').clearValidators();
    this.reportForm.get('toDate').clearValidators();
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').clearValidators();
    this.reportForm.get('assessment').clearValidators();
    this.reportForm.get('sapId').clearValidators();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('assessment').updateValueAndValidity();
    this.reportForm.get('sapId').updateValueAndValidity();
  }

  toggleValidationForEmployeeReport(){
    this.reportForm.get('fromDate').clearValidators();
    this.reportForm.get('toDate').clearValidators();
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').clearValidators();
    this.reportForm.get('assessment').clearValidators();
    this.reportForm.get('sapId').setValidators([Validators.required, Validators.pattern(digitPattern), Validators.maxLength(8), Validators.minLength(8)]);
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('assessment').updateValueAndValidity();
    this.reportForm.get('sapId').updateValueAndValidity();
  }

  validateDate(){
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'yyyy-MM-dd');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'yyyy-MM-dd');
    if(fromDate > toDate){
      this.snackBar.open('Start date cannot be greater then end date.', 'OK', {duration: snackBarDuration});
      return false;
    }else{
      return true;
    }
  }

  getReport(reportType){
    if(reportType == 'Question Category Specific Reports'){
      if(this.validateDate()){
        this.getCategoryWiseAIReport();
      } 
    } else if(reportType == 'Frequent Low Scorer Report'){
      this.getLowScoreWiseAIReport();
    } else if(reportType == 'Frequent High Scorer Report'){
      this.getHighScoreWiseAIReport();
    } else if(reportType == 'Question Wise Analysis Report'){
      if(this.validateDate()){
        this.getQuestionWiseAIReport();
      }
    } else if(reportType == 'Detailed Employee Report'){
      this.getEmployeeWiseAIReport();      
    }
  }

  getCategoryWiseAIReport(){
    // get category wise data report
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
   
    let lobId = this.reportForm.get('lob').value.lobId;
    let subLobId = null;
    if(this.reportForm.get('subLob').value){
      subLobId = this.reportForm.get('subLob').value.subLobId;
    }
    this.reportService.getCategoryWiseAIReport(fromDate, toDate, lobId, subLobId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.employeeLagOnCategoryReport = res;
        this.createCategoryLagList(res)
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.showReport = true;
        this.employeeLagOnCategoryReport = null;
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  createCategoryLagList(res){
    this.categoryLagList = [];
    let wronglyAnsweredQuestionsCount = res.wronglyAnsweredQuestionsCount;
    let categorySpecificDetailsMap = res.categorySpecificDetailsMap; 
    if(wronglyAnsweredQuestionsCount != {}){
      this.categoryList.forEach(category => {
        if(wronglyAnsweredQuestionsCount[category.categoryName]){
          let obj = {
            category: category.categoryName,
            count: wronglyAnsweredQuestionsCount[category.categoryName],
            data:categorySpecificDetailsMap[category.categoryName]
          }
          this.categoryLagList.push(obj);
        }
      })
    }
  }

  getLowScoreWiseAIReport(){
    this.loader.open();
    let lobId = this.reportForm.get('lob').value.lobId;
    let subLobId = null;
    if(this.reportForm.get('subLob').value){
      subLobId = this.reportForm.get('subLob').value.subLobId;
    }
    this.reportService.getLowScoreWiseAIReport(lobId, subLobId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.employeeFailingWithLowerScore = res;
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.showReport = true;
        this.employeeFailingWithLowerScore = [];
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getHighScoreWiseAIReport(){
    this.loader.open();
    let lobId = this.reportForm.get('lob').value.lobId;
    let subLobId = null;
    if(this.reportForm.get('subLob').value){
      subLobId = this.reportForm.get('subLob').value.subLobId;
    }
    this.reportService.getHighScoreWiseAIReport(lobId, subLobId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.employeePassingWithHigherScore = res;
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.showReport = true;
        this.employeePassingWithHigherScore = [];
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getQuestionWiseAIReport(){
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
    let assessmentId = this.reportForm.get('assessment').value.assessmentId;
    
    this.reportService.getQuestionWiseAIReport(fromDate, toDate, assessmentId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.questionWiseAnalysisReport = res;
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.showReport = true;
        this.questionWiseAnalysisReport = [];
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getEmployeeWiseAIReport(){
    this.getEmployeeWiseSummary();
    
  }

  getEmployeeWiseSummary(){
    this.loader.open();
    let lobId = this.reportForm.get('lob').value.lobId;
    let sapId = this.reportForm.get('sapId').value;
    this.reportService.getEmployeeWiseSummaryAlReport(lobId, sapId)
    .subscribe(res => {
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.employeeWiseSummaryReport = this.createEmployeeSummaryObj(res);
        this.showReport = true; 
       this.getEmployeeWiseDetailReport();
      }
      this.loader.close();
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.showReport = true;
        this.employeeWiseSummaryReport = null;
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  createEmployeeSummaryObj(data){
    let obj = {
      SAP_ID: data.userId,
      Employee_Name: data.employeeName,
      Total_Assessment: data.totalAssessment,
      Assessment_Passed: data.passAssessment,
      Assessment_Failed: data.failAssessment,
      Assessment_Pending: data.pendingAssessment,
      // Application_Percent: data.applicationPercent,
      // Behavioral_Percent: data.behavioralPercent,
      // Client_Specific_Percent: data.clientSpecificPercent,
      // Domain_Percent: data.domainPercent,
      // Process_Percent: data.processPercent,
      // Soft_Skill_Percent: data.softSkilPercent
      catRes: data.catRes
    }
    return obj;
  }

  getEmployeeWiseDetailReport(){
    // this.loader.open();
    let lobId = this.reportForm.get('lob').value.lobId;
    let sapId = this.reportForm.get('sapId').value;
    this.reportService.getEmployeeWiseAlReport(lobId, sapId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.employeeWiseDetailedReport = this.removeSpecialCharacterFromReport(res);
        this.showReport = true;
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.showReport = true;
        this.employeeWiseDetailedReport = [];
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  removeSpecialCharacterFromReport(res){
    let empArr = res;
    empArr.forEach(obj => {
      obj.catRes.forEach(cat=>{
        if (cat.category.indexOf('_') > -1){
          let s = cat.category.replace(/_/g, ' ');
          cat.category = s;
        }
      })
    })
    return empArr;
  }


  downloadReport(){
    let reportType = this.reportForm.get('reportType').value;
    switch(reportType){
      case 'Question Category Specific Reports': {
        this.downloadCategoryLagReport(this.categoryLagList);
        break;
      }
      case 'Frequent Low Scorer Report': {
        this.downloadLowScoreReport(this.employeeFailingWithLowerScore);
        break;
      }
      case 'Frequent High Scorer Report': {
        this.downloadHighScoreReport(this.employeePassingWithHigherScore);
        break;
      }
      case 'Question Wise Analysis Report': {
        this.downloadQuestionAnalysisReport(this.questionWiseAnalysisReport);
        break;
      }
      case 'Detailed Employee Report': {
        this.downloadEmployeeDetailReport(this.employeeWiseDetailedReport)
        break;
      }
      default : {
        break;
      }
    }
  }

  downloadCategoryLagReport(report){
    let summaryData = [];
    if(this.employeeLagOnCategoryReport.wronglyAnsweredQuestionsCount != {}){
      for (const [key, value] of Object.entries(this.employeeLagOnCategoryReport.wronglyAnsweredQuestionsCount)) {
        let obj = this.createSummaryDataForCategory(key,value);
        summaryData.push(obj);
      }
    }
    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(summaryData);
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Summary');
    this.categoryLagList.forEach(cat => {
      let downLoadReport = [];
      cat.data.forEach(data => {
        let obj = this.createCategoryLagReport(data);
        downLoadReport.push(obj);
      })  
      const ws2: XLSX.WorkSheet = XLSX.utils.json_to_sheet(downLoadReport);
      const wb2: XLSX.WorkBook = XLSX.utils.book_new(); 
      XLSX.utils.book_append_sheet(wb1,ws2, cat.category);
    })
    
    XLSX.writeFile(wb1, 'Question Category Specific Report.xlsx');
  }

  downloadLowScoreReport(report){
    let downloadReport = []
    this.employeeFailingWithLowerScore.forEach( data => {
      let obj = this.createScoreReport(data);
      downloadReport.push(obj);
    })
    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(downloadReport);  
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Employee With Low Score Report');
    XLSX.writeFile(wb1, 'Frequent Low Scorer Report.xlsx');
  }

  downloadHighScoreReport(report){
    let downloadReport = []
    this.employeePassingWithHigherScore.forEach( data => {
      let obj = this.createScoreReport(data);
      downloadReport.push(obj);
    })
    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(downloadReport);  
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Employee With Hign Score Report');
    XLSX.writeFile(wb1, 'Frequent High Scorer Report.xlsx');
  }

  downloadQuestionAnalysisReport(report){
    let downloadReport = []
    let i =0;
    this.questionWiseAnalysisReport.forEach( data => {
      i++;
      let obj = this.createQuestionAnalysisReport(data, i);
      downloadReport.push(obj);
    })
    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(downloadReport);  
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Question Wise Analysis Report');
    XLSX.writeFile(wb1, 'Question Wise Analysis Report.xlsx');
  }

  downloadEmployeeDetailReport(report){
    this.loader.open();
    let summaryReport = [];
    let detailReport = [];
    if(this.employeeWiseSummaryReport != {} && this.employeeWiseSummaryReport != null){
      let tempSummaryData = {...this.employeeWiseSummaryReport};
      let categoryArray = this.catSummaryData(this.employeeWiseSummaryReport.catRes);
          categoryArray.forEach(cat => {
          tempSummaryData[cat.category] = cat.score;
      })
      delete tempSummaryData.catRes;
      
      for (const [key, value] of Object.entries(tempSummaryData)) {
        let obj = this.createEmployeeSummaryReport(key,value);
        summaryReport.push(obj);
      }
    }
    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(summaryReport, {skipHeader: true});
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Summary');
    this.employeeWiseDetailedReport.forEach(data => {
      let obj = this.createEmployeeDetailReport(data);
      detailReport.push(obj);
    })
    const ws2: XLSX.WorkSheet = XLSX.utils.json_to_sheet(detailReport);
    const wb2: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws2, 'Details');

    XLSX.writeFile(wb1, 'Detailed Employee Report.xlsx');
    this.loader.close();
  }

  createEmployeeSummaryReport(key, value){
    let obj = {
      fields: key,
      value: value
    }
    return obj;
  }

  createEmployeeDetailReport(data){
    let obj = {
      "Employee SAP ID": data.userId,
      "Employee Name":data.employeeName,
      "Assessment Name": data.assessmentName,
      "Assessment Date": new DatePipe('en-US').transform(data.quizDate, 'dd-MM-yyyy'),
      "LOB": data.lob,
      "Sub LOB": data.subLob,
      "Total Duration": data.totalDuration,
      "Quiz Duration": data.quizDuration,
      "Passing Percent": data.passingPercent,
      "Total Marks": data.totalMarks,
      "Obtained Marks": data.obtainedMarks,
      "Assessment Score": data.quizScore,
      "Assessment Outcome": data.quizOutcome,
      // Application: data.application,
      // Behavioral: data.behavioral,
      // Client_Specific: data.clientSpecific,
      // Domain: data.domain,
      // Process: data.process,
      // Soft_Skill: data.softSkill
    }
    let categoryArray = this.catData(data.catRes);
      categoryArray.forEach(cat => {
        obj[cat.category + ' Percent'] = cat.score;
      })
    return obj;
  }

  createSummaryDataForCategory(key, value){
    let obj = {
      "Question Category": key,
      "Count of Users Who Answered Questions Wrongly": value
    };
    return obj;
  }

  createCategoryLagReport(data){
    let obj = {
      "Emp SAP Id": data.sapId,
      "PSID": data.psId,
      "Name": data.employeeName,
      "LOB": data.lob,
      "Sub LOB": data.subLob,
      "Total Questions Attended": data.totalQuestions,
      "Total Correct": data.correctQuestions,
      "Total Worng": data.wrongQuestions,
      "Average": data.averageQuestions
    } 
    return obj;
  }

  createScoreReport(data){
    let obj = {
      "SAP ID": data.userId,
      "Name": data.employeeName,
      "LOB": this.reportForm.get('lob').value.lobName,
      "Sub LOB": data.sublobName,
      "Average": data.average
    }
    return obj;
  }

  createQuestionAnalysisReport(data, i){
    let obj = {
      "Sl.No": i,
      "Question": data.question,
      "Category": data.category,
      "Total Attempts": data.totalCount,
      "Correct Attempts": data.correct,
      "Wrong Attempts": data.wrong,
      "Average Correct": data.correctAvg,
      "Average Wrong": data.wrongAvg
    }
    return obj;
  }

  clearReportOnSelectionChange(){
    this.employeeLagOnCategoryReport = null;
    this.employeeFailingWithLowerScore = [];
    this.employeePassingWithHigherScore = [];
    this.questionWiseAnalysisReport = [];
    this.employeeWiseDetailedReport = [];
    this.employeeWiseSummaryReport = null;
    this.showReport = false;
  }

  resetData(){
    //this.createReportForm();
    this.employeeLagOnCategoryReport = null;
    this.employeeFailingWithLowerScore = [];
    this.employeePassingWithHigherScore = [];
    this.questionWiseAnalysisReport = [];
    this.employeeWiseDetailedReport = []; //test
    this.employeeWiseSummaryReport = null;
    this.showReport = false;
    this.assessmentList = [];
    let reportType = this.reportForm.get('reportType').value;
    this.reportForm.get('fromDate').setValue('');
    this.reportForm.get('toDate').setValue('');
    this.reportForm.get('lob').setValue([]);
    this.reportForm.get('subLob').setValue([]);
    this.reportForm.get('assessment').setValue([]);
    this.reportForm.get('sapId').setValue('');
    if(reportType == 'Question Category Specific Reports'){
      this.initialValidation();
    }else if(reportType == 'Frequent Low Scorer Report'){
     this.toggleValidationForClearDate(); 
    } else if(reportType == 'Frequent High Scorer Report'){
      this.toggleValidationForClearDate();
    } else if(reportType == 'Question Wise Analysis Report'){
      this.toggleValidationForQuestionWiseAIReport();
    }else if(reportType == 'Detailed Employee Report'){
      this.toggleValidationForEmployeeReport();
    }
  }
}