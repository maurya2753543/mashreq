import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import { AdminReportComponent } from './admin-report/admin-report.component';

import { SharedModule } from '../../shared/shared.module';

import { MatCardModule } from '@angular/material/card';
import { MatDividerModule, MatListModule } from '@angular/material'
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule, MatButtonModule } from '@angular/material';
import { MatSelectModule } from '@angular/material/select';
import { NgxPaginationModule } from 'ngx-pagination';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { MatTabsModule } from '@angular/material/tabs';

import { AppLoaderComponent } from '../../shared/services/app-loader/app-loader.component';
import { AiReportComponent } from './ai-report/ai-report.component';



@NgModule({
  declarations: [ReportsComponent, AdminReportComponent, AiReportComponent],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    MatCardModule,
    MatDividerModule,
    MatListModule,
    FormsModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    SelectDropDownModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatTabsModule,
    NgxPaginationModule,
    SharedModule  
  ],
  entryComponents: [AppLoaderComponent]
})
export class ReportsModule { }
