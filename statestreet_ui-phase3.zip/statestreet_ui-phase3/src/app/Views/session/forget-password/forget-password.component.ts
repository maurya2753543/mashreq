import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { SessionService } from '../session.service';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { digitPattern, appSessionErr, snackBarDuration, resetLocalStorage, appGenericErr, appVariables } from '../../../app.constants';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {

  public forgetPasswordForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private sessionService: SessionService,
    private snackBar: MatSnackBar,
    private router: Router,
    private loader: AppLoaderService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.forgetPasswordForm = this.fb.group({
      sapId: new FormControl('', [Validators.required, Validators.maxLength(8),Validators.pattern(digitPattern)]),
      doj: new FormControl('', [Validators.required]),
    });
  }

  checkAuthentication(){
    this.loader.open();
    let sapId = this.forgetPasswordForm.get('sapId').value;
    let doj = new DatePipe('en-US').transform(this.forgetPasswordForm.get('doj').value, 'dd-MMM-yy');
    this.sessionService.forgotPasswordAuthenticationCheck(sapId, doj)
    .subscribe(res => {
      this.loader.close();
      if(res.Status == 'Success'){
        this.router.navigate(['/resetForgetPassword',this.forgetPasswordForm.get('sapId').value]);
      }else{
        this.snackBar.open('Invalid SAP Id or Joining Date', 'OK', {duration: snackBarDuration}); 
      }
    }, err => {
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration}); 
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Invalid SAP Id or Joining Date', 'OK', {duration: snackBarDuration}); 
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
      this.loader.close();
    })
  }

}
