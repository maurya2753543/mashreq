import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SessionRoutingModule } from './session-routing.module';
import { SessionComponent } from './session.component';
import { SigninComponent } from './signin/signin.component';
import { AppLoaderComponent } from '../../shared/services/app-loader/app-loader.component';
import { SharedModule } from '../../shared/shared.module';

import { MatCardModule } from '@angular/material/card';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { MatDatepickerModule, MatNativeDateModule, MatIconModule } from '@angular/material';
import { ResetForgotPasswordComponent } from './reset-forgot-password/reset-forgot-password.component';

@NgModule({
  declarations: [SessionComponent, SigninComponent, ResetPasswordComponent, ForgetPasswordComponent, ResetForgotPasswordComponent],
  imports: [
    CommonModule,
    MatCardModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    SessionRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  entryComponents: [AppLoaderComponent]
})
export class SessionModule { }
