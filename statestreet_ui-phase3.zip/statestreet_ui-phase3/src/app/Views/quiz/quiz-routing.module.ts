import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AgentQuizComponent } from './agent-quiz/agent-quiz.component';
import { QuestionSetComponent } from './question-set/question-set.component';


const routes: Routes = [
  { path: '', component: AgentQuizComponent },
  { path: 'set/:id', component: QuestionSetComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QuizRoutingModule { }
