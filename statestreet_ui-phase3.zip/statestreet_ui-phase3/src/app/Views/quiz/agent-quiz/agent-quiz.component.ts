import { Component, OnInit } from '@angular/core';
import { QuizService } from '../quiz.service';
import { MatSnackBar } from "@angular/material";
import { Router } from '@angular/router';
import { appSessionErr, appGenericErr, appVariables, resetLocalStorage, snackBarDuration } from 'src/app/app.constants';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';

@Component({
  selector: 'app-agent-quiz',
  templateUrl: './agent-quiz.component.html',
  styleUrls: ['./agent-quiz.component.scss']
})
export class AgentQuizComponent implements OnInit {

  public assessmentList = [];
  public selectedAssessmentId;
  public questionList;
  public questionSet;

  constructor(
    private quizService: QuizService,
    private snackBar: MatSnackBar,
    private router: Router,
    private loader: AppLoaderService
  ) { }

  ngOnInit() {
    this.getAssessment();
  }

  getAssessment(){
    this.loader.open();
    this.quizService.getAssessment()
    .subscribe(res => {
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }
      else if(res == null){
        this.snackBar.open('No Assessment found for employee.', 'OK', {duration: snackBarDuration});
      }else{
        this.assessmentList = res;
      }
      this.loader.close();
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
}
