import { Component, OnInit } from '@angular/core';
import { AppLoaderService} from '../../shared/services/app-loader/app-loader.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  public selected = 'ADMIN';

  constructor(
    private loader: AppLoaderService
  ) { }

  ngOnInit() {
  }

}
