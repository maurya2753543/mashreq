import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoAssessmentComponent } from './auto-assessment.component';

describe('AutoAssessmentComponent', () => {
  let component: AutoAssessmentComponent;
  let fixture: ComponentFixture<AutoAssessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoAssessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoAssessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
