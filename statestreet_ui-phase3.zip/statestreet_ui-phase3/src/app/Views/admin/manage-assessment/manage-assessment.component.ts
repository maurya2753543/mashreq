import { Component, OnInit, ViewChild, AfterContentChecked, ChangeDetectorRef, Input } from '@angular/core';
import { MatTabGroup } from '@angular/material';

@Component({
  selector: 'app-manage-assessment',
  templateUrl: './manage-assessment.component.html',
  styleUrls: ['./manage-assessment.component.scss']
})
export class ManageAssessmentComponent implements OnInit, AfterContentChecked {

  @ViewChild('tabGroup', { static: false }) private tabGroup: MatTabGroup;
  public newItemEvent:number = 0;

  constructor( private changeDetector: ChangeDetectorRef) { }

  ngOnInit() {
  }

  ngAfterContentChecked() : void {
    this.changeDetector.detectChanges();
  }

  addItem(value) {
    //this.newItemEvent = value;
    this.tabGroup.selectedIndex = value;
  }

}
