import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserOptionComponent } from './add-user-option.component';

describe('AddUserOptionComponent', () => {
  let component: AddUserOptionComponent;
  let fixture: ComponentFixture<AddUserOptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserOptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
