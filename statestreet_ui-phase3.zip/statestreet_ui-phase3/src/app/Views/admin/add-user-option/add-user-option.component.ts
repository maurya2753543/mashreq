import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-user-option',
  templateUrl: './add-user-option.component.html',
  styleUrls: ['./add-user-option.component.scss']
})
export class AddUserOptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
