import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bulk-upload-question',
  templateUrl: './bulk-upload-question.component.html',
  styleUrls: ['./bulk-upload-question.component.scss']
})
export class BulkUploadQuestionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
