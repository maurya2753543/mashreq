import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../admin.service';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { appSessionErr, snackBarDuration, resetLocalStorage, appVariables, appGenericErr } from '../../../../../app.constants';

@Component({
  selector: 'app-manage-lob',
  templateUrl: './manage-lob.component.html',
  styleUrls: ['./manage-lob.component.scss']
})
export class ManageLobComponent implements OnInit {

  public lobSelected;
  public config;
  public lobList = [];
  public lob = '';
  public subLob = '';

  constructor(
    private adminService: AdminService,
    private loader: AppLoaderService,
    private snackBar: MatSnackBar,
    private router: Router
  ) {
    this.config = {
      displayKey:"lobName", //if objects array passed which key to be displayed defaults to description
      search:true,//true/false for the search functionlity defaults to false,
      height: '200px', //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
      placeholder:'Select', // text to be displayed when no item is selected defaults to Select,
      customComparator: ()=>{}, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
      limitTo: this.lobList.length, // a number thats limits the no of options displayed in the UI similar to angular's limitTo pipe
      moreText: 'more', // text to be displayed whenmore than one items are selected like Option 1 + 5 more
      noResultsFound: 'No results found!', // text to be displayed when no items are found while searching
      searchPlaceholder:'Search', // label thats displayed in search input,
      searchOnKey: 'lobName' // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
      }
   }

  ngOnInit() {
    this.getAllLob();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.loader.close();
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.loader.close();
        this.lobList = res;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  saveLob(){
    this.loader.open();
    let lobData = {
      lobName: this.lob
    }
    this.adminService.saveLob(lobData)
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else{
        this.loader.close();
        this.snackBar.open('LOB Saved Successfully', 'OK', {duration: snackBarDuration});
        this.resetData();
      }
      
    },err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else if(err.status == '400'){
        this.snackBar.open('Invalid LOB Name', 'OK', {duration: snackBarDuration});
      }
        else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  saveSubLob(){
    this.loader.open();
    let subLobData = {
      subLobName: this.subLob,
      lob: {
        lobName: this.lobSelected.lobName
      }
    }
    this.adminService.saveSubLob(subLobData)
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else{
        this.loader.close();
        this.snackBar.open('Sub LOB Saved Successfully', 'OK', {duration: snackBarDuration});
        this.resetData();
      }
      
    },err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else if(err.status == '400'){
        this.snackBar.open('Invalid SUB LOB Name', 'OK', {duration: snackBarDuration});
      }
        else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  resetData(){
    this.lob = '';
    this.subLob = '';
    this.lobList = [];
    this.getAllLob();
  }

}
