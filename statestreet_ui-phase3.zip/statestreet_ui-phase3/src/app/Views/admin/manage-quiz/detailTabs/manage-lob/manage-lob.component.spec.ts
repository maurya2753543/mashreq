import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageLobComponent } from './manage-lob.component';

describe('ManageLobComponent', () => {
  let component: ManageLobComponent;
  let fixture: ComponentFixture<ManageLobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageLobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageLobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
