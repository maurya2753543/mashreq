import { Component, OnInit, ViewChild, AfterContentChecked, ChangeDetectorRef } from '@angular/core';
import { MatTabGroup } from '@angular/material';

@Component({
  selector: 'app-training-tracker',
  templateUrl: './training-tracker.component.html',
  styleUrls: ['./training-tracker.component.scss']
})
export class TrainingTrackerComponent implements OnInit, AfterContentChecked {

  @ViewChild('tabGroup', { static: false }) private tabGroup: MatTabGroup;

  constructor(private changeDetector: ChangeDetectorRef) { }

  ngOnInit() {
  }

  ngAfterContentChecked() : void {
    this.changeDetector.detectChanges();
  }

}
