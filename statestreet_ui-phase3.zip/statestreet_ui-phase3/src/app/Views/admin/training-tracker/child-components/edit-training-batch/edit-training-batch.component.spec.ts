import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTrainingBatchComponent } from './edit-training-batch.component';

describe('EditTrainingBatchComponent', () => {
  let component: EditTrainingBatchComponent;
  let fixture: ComponentFixture<EditTrainingBatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditTrainingBatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTrainingBatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
