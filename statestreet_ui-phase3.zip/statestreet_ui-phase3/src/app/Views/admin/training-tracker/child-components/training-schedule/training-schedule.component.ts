import { Component, OnInit, Input } from '@angular/core';
import { appTrainingScheduleStatus, appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables } from '../../../../../app.constants';
import { AdminService } from '../../../admin.service';
import { MatSnackBar, MatDialog } from '@angular/material';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import * as cloneDeep from 'lodash/cloneDeep';
import * as moment from 'moment';

@Component({
  selector: 'app-training-schedule',
  templateUrl: './training-schedule.component.html',
  styleUrls: ['../training-component.scss']
})
export class TrainingScheduleComponent implements OnInit {

  @Input() trainingBatch: any;
  public trainingScheduleList = [];
  public trainingScheduleStatus = appTrainingScheduleStatus;
  public currentPage = 1;
  public itemsPerPage = 6;
  public minDate;
  public maxDate;
  public dateError = '';
  public currectDate: Date = new Date();

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private loader: AppLoaderService,
    private router: Router,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.minDate = moment(this.trainingBatch.trainingBatchStartDate).toDate();
    this.maxDate = moment(this.trainingBatch.trainingBatchEndDate).toDate();
    this.createTrainingScheduleData();
    this.getTrainingSchedule();
  }

  createTrainingScheduleData(){
    if(this.trainingBatch.trainingPlan.trainingPlanWeek.length > 0){
      this.trainingBatch.trainingPlan.trainingPlanWeek.forEach(week => {
        if(week.taskList.length > 0){
          week.taskList.forEach(task => {
            let weekObj = {
              trainingBatchScheduleId: '',
              trainingBatchId: this.trainingBatch.trainingBatchId,
              trainingBatchName: this.trainingBatch.trainingBatchName,
              trainingPlanId: this.trainingBatch.trainingPlan._id,
              trainingPlanName: this.trainingBatch.trainingPlan.trainingPlanName,
              trainingPlanWeekName: week.weekName,
              trainingPlanWeekTitle: week.weekTitle,
              trainingPlanTask: {
                taskId: task._id,
                taskName: task.taskName
              },
              //trainingPlanTaskName: task.taskName,
              trainingPlanTaskStatus: 'Yet_To_Start',
              trainingPlanTaskScheduleDate: null
            }
            this.trainingScheduleList.push(weekObj);
          })
        }
      })
    }
  }

  getTrainingSchedule(){
    this.loader.open();
    let trainingPlanId = this.trainingBatch.trainingPlan._id;
    this.adminService.getTrainingBatchSchedule(trainingPlanId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Training is not yet Schedule for selected Training Batch.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.setTraininPlanSchedule(res);
        }
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Training is not yet Schedule for selected Training Batch.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  setTraininPlanSchedule(res){
    res.forEach(response => {
      this.trainingScheduleList.forEach(training => {
        if(training.trainingPlanTask.taskId == response.trainingPlanTask.taskId
          && training.trainingPlanWeekName == response.trainingPlanWeekName 
          && training.trainingPlanWeekTitle == response.trainingPlanWeekTitle){
          training.trainingPlanTaskStatus = response.trainingPlanTaskStatus;
          training.trainingPlanTaskScheduleDate = response.trainingPlanTaskScheduleDate!= null ? new Date(response.trainingPlanTaskScheduleDate.replace(/-/g,' ')) : null;
        }
      })
    })
  }

  private validateDate(data){
    let count = 0;
    data.forEach(data => {
      if(data.trainingPlanTaskStatus != 'Yet_To_Start' && data.trainingPlanTaskScheduleDate == null){
        this.dateError = 'Please specify date for tasks whose status is updated.'
        count++;
      }
    })
    if(count > 0){
      return false;
    }else{
      return true;
    }
  }

  saveTrainingScheduleData(){
    this.dateError = '';
    let data = cloneDeep(this.trainingScheduleList);
    data.forEach(data => {
      if(data.trainingPlanTaskScheduleDate != null){
        data.trainingPlanTaskScheduleDate = new DatePipe('en-US').transform(data.trainingPlanTaskScheduleDate, 'yyyy-MMM-dd')
      }
    })
    if(this.validateDate(data)){
    this.loader.open();
      this.adminService.saveTrainingBatchSchedule(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Training Batch Schedule saved successfully', 'OK', {duration: snackBarDuration});
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  }

}
