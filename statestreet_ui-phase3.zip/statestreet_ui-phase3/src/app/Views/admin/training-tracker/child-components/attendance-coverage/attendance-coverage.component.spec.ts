import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceCoverageComponent } from './attendance-coverage.component';

describe('AttendanceCoverageComponent', () => {
  let component: AttendanceCoverageComponent;
  let fixture: ComponentFixture<AttendanceCoverageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendanceCoverageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendanceCoverageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
