import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTrainingBatchComponent } from './create-training-batch.component';

describe('CreateTrainingBatchComponent', () => {
  let component: CreateTrainingBatchComponent;
  let fixture: ComponentFixture<CreateTrainingBatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateTrainingBatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTrainingBatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
