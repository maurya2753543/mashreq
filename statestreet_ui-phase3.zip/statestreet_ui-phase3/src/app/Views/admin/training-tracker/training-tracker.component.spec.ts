import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingTrackerComponent } from './training-tracker.component';

describe('TrainingTrackerComponent', () => {
  let component: TrainingTrackerComponent;
  let fixture: ComponentFixture<TrainingTrackerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainingTrackerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingTrackerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
