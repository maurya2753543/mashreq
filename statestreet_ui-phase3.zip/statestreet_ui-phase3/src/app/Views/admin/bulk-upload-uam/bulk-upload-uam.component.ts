import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bulk-upload-uam',
  templateUrl: './bulk-upload-uam.component.html',
  styleUrls: ['./bulk-upload-uam.component.scss']
})
export class BulkUploadUamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
