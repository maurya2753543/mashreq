import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule } from "@angular/router";

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';

import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTabsModule } from '@angular/material/tabs';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule, MatNativeDateModule, MatIconModule } from '@angular/material';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { MatDividerModule } from '@angular/material/divider';

import { SharedModule } from '../../shared/shared.module';
import { UamComponent } from './uam/uam.component';
import { ManageQuizComponent } from './manage-quiz/manage-quiz.component';
import { AddQuestionComponent } from './manage-quiz/detailTabs/add-question/add-question.component';
import { QuestionComponent } from "./manage-quiz/detailTabs/add-question/QuestionComponent";
import { UpdateQuestionComponent, QuestionEditDialogComponent } from './manage-quiz/detailTabs/update-question/update-question.component';;
import { UpdateQuestionBankComponent } from './manage-quiz/detailTabs/update-question-bank/update-question-bank.component';
import { AddUserOptionComponent } from './add-user-option/add-user-option.component';
import { BulkUploadUamComponent } from './bulk-upload-uam/bulk-upload-uam.component';
import { BulkUploadQuestionComponent } from './manage-quiz/detailTabs/bulk-upload-question/bulk-upload-question.component';
import { AddAssessmentComponent } from './manage-assessment/tabDetails/add-assessment/add-assessment.component';
import { AppLoaderComponent } from '../../shared/services/app-loader/app-loader.component';
import { AssessmentEvaluationComponent } from './assessment-evaluation/assessment-evaluation.component';
import { ManageLobComponent } from './manage-quiz/detailTabs/manage-lob/manage-lob.component';
import { AutoAssessmentComponent } from './manage-assessment/tabDetails/auto-assessment/auto-assessment.component';
import { ManageAssessmentComponent } from './manage-assessment/manage-assessment.component';
import { ManageCategoryComponent } from './manage-quiz/detailTabs/manage-category/manage-category.component';
import { ViewAssessmentComponent, EditAssessmentDialogComponent } from './manage-assessment/tabDetails/view-assessment/view-assessment.component';

import { MatDialogModule } from '@angular/material/dialog';
import { TrainingTrackerComponent } from './training-tracker/training-tracker.component';

import { CreateTrainingBatchComponent } from './training-tracker/child-components/create-training-batch/create-training-batch.component';
import { EditTrainingBatchComponent, EditTrainingBatchDialog } from './training-tracker/child-components/edit-training-batch/edit-training-batch.component';
import { CreateTrainingPlanComponent } from './training-tracker/child-components/create-training-plan/create-training-plan.component';
import { AttendanceCoverageComponent } from './training-tracker/child-components/attendance-coverage/attendance-coverage.component';
import { BatchSpecificReportComponent } from './training-tracker/child-components/batch-specific-report/batch-specific-report.component';
import { TrainingScheduleComponent } from './training-tracker/child-components/training-schedule/training-schedule.component';
import { EditTrainingPlanComponent } from './training-tracker/child-components/edit-training-plan/edit-training-plan.component';

@NgModule({
  declarations: [
    AdminComponent, 
    UamComponent,
    ManageQuizComponent, 
    AddQuestionComponent, 
    QuestionComponent, 
    UpdateQuestionComponent, 
    QuestionEditDialogComponent, 
    UpdateQuestionBankComponent, 
    AddUserOptionComponent, 
    BulkUploadUamComponent, 
    BulkUploadQuestionComponent, 
    AddAssessmentComponent, 
    AssessmentEvaluationComponent, 
    ManageLobComponent, 
    AutoAssessmentComponent, 
    ManageAssessmentComponent, 
    ManageCategoryComponent, 
    ViewAssessmentComponent,
    EditAssessmentDialogComponent,
    TrainingTrackerComponent,
    CreateTrainingBatchComponent,
    EditTrainingBatchComponent,
    EditTrainingBatchDialog,
    CreateTrainingPlanComponent,
    AttendanceCoverageComponent,
    BatchSpecificReportComponent,
    TrainingScheduleComponent,
    EditTrainingPlanComponent],
  imports: [
    CommonModule,
    MatCardModule,
    MatSelectModule,
    MatMenuModule,
    FlexLayoutModule,
    MatTooltipModule,
    FormsModule,
    MatSlideToggleModule,
    MatDialogModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatInputModule,
    MatDividerModule,
    MatButtonModule,
    AdminRoutingModule,
    MatExpansionModule,
    MatTabsModule,
    RouterModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatNativeDateModule,
    SelectDropDownModule,
    NgxPaginationModule,
    MatIconModule,
    SharedModule
  ],
  entryComponents: [
    AppLoaderComponent,
    QuestionEditDialogComponent,
    EditAssessmentDialogComponent,
    EditTrainingBatchDialog]
})
export class AdminModule { }
