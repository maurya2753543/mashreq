import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MatDialogModule} from '@angular/material/dialog';
import { ChatbotdialogComponent } from './chatbotdialog/chatbotdialog.component';
import {MatButtonModule} from '@angular/material/button';
import{BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';
import { ChatService } from './services/chat/chat.service';
import{HttpClientModule,HttpClient} from '@angular/common/http'
import { HttpModule } from '@angular/http';
@NgModule({
  declarations: [
    AppComponent,
    ChatbotdialogComponent,
    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    AppRoutingModule,
    MatDialogModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatInputModule

  ],
  entryComponents:[
    ChatbotdialogComponent
  ],

  providers: [ChatService],
  bootstrap: [AppComponent]
})
export class AppModule { }
