import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ChatbotdialogComponent } from './chatbotdialog/chatbotdialog.component';
import{ChatService} from './services/chat/chat.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ibmwatson';
message:any;
sessionId:any;
  constructor(public dialog: MatDialog,private chatservice:ChatService) {
    this.sendmsg()
    this.customQuestions()
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ChatbotdialogComponent, {
      width: '360px',
      height: '490px',
      
     
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    
    });
   

  }
  sendmsg(){
    this.chatservice.setSession().subscribe((response:any)=>{
      this.sessionId=response.result.session_id
      let data={
        message:this.message ? this.message :'',
        session_id:response.result.session_id
      }
      this.sendmsgtowatson(data)
   
    })
  }
sendmsgtowatson(data:any)
{
  this.chatservice.sendmsgtowatson(data).subscribe((result:any)=>{
    console.log(result,'---------------')
  }) 
}

customQuestions(){
  this.chatservice.getQuestions().subscribe((result:any)=>{
    console.log(result,'customquestions-->>>>>>>>>>>')
  })
}
   
}
