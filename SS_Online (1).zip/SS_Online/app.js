
'use strict';

var express = require('express'); // app server
var bodyParser = require('body-parser'); // parser for post requests
var AssistantV2 = require('ibm-watson/assistant/v2'); // watson sdk
const { IamAuthenticator, BearerTokenAuthenticator } = require('ibm-watson/auth');
var cors=require('cors')
var app = express();
const axios=require('axios')
// require('./health/health')(app);
app.use(cors())
// Bootstrap application settings
app.use(express.static('./public')); // load UI from public folder
app.use(bodyParser.json());

// Create the service wrapper

let authenticator;
if (process.env.ASSISTANT_IAM_APIKEY) {
  authenticator = new IamAuthenticator({
    apikey: process.env.ASSISTANT_IAM_APIKEY
  });
} else if (process.env.BEARER_TOKEN) {
  authenticator = new BearerTokenAuthenticator({
    bearerToken: process.env.BEARER_TOKEN
  });
}

var assistant = new AssistantV2({
  version: '2020-12-23',
  authenticator: authenticator,
  url: process.env.ASSISTANT_URL,
  disableSslVerification:true
});

// Endpoint to be call from the client side
app.post('/api/message', function(req, res) {
  console.log('/////')
  let assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
  if (!assistantId || assistantId === '<assistant-id>') {
    return res.json({
      output: {
        text:"Error"
          
      }
    });
  }
console.log(req.body,'llll')
  
    var textIn = req.body.message ? req.body.messae:'';
  

  var payload = {
    assistantId: assistantId,
    sessionId: req.body.session_id,
    input: {
      message_type: 'text',
      text: textIn,
    },
  };

  // Send the input to the assistant service
  assistant.message(payload, function(err, data) {
    if (err) {
      const status = err.code !== undefined && err.code > 0 ? err.code : 500;
      return res.status(status).json(err);
    }
console.log(data.result.output,'data')
    return res.json(data.result.output.generic);
  });
});

app.get('/api/session', function(req, res) {
  assistant.createSession(
    {
      assistantId: process.env.ASSISTANT_ID || '{assistant_id}',
    },
    function(error, response) {
      if (error) {
        console.log(error,'error')
        return res.send(error);
      } else {
      
        return res.send(response);
      }
    }
  );
});

app.get('/api/customQuestions',async(req,res)=>{
console.log('reached here at api+++++++++++')
try{
  let response=await axios.get('https://statestreetquizdev-phase3.mybluemix.net/api/user/getQuestionList',{ headers: {
    Authorization:'Bearer'+' '+'4e827499-dfdb-4ceb-ab6b-7b17150e617c'//the token is a variable which holds the token
},params: { userId: 51758196 }})
  
 return res.json(response.data)
}

catch(e)
{
  console.log(e,'Error')
}
})
module.exports = app;
