{
    "dataSet" : [
        ["Nilisha", "nilisha.gupta@hcl.com","988765263", "999", "120","21/01/2121", "20/01/2121", "22/01/2121"],
        ["Mrinal", "mrinal.singh@hcl.com", "988765263", "898", "220","12/01/2121", "11/01/2121", "19/01/2121"],
        ["Manish", "manish.seth@hcl.com", "988765263", "9876", "320","27/01/2121", "8/01/2121", "16/01/2121"],
        ["Ruchi", "ruchi.bisht@hcl.com", "988765263", "9987", "420","28/01/2121", "2/02/2121", "11/02/2121"]

    ],

    "ColumnHeading" :
    [
            { "title": "Name", "sTitle": "Name" },
            { "title": "Email Id", "sTitle": "Email Id" },
            { "title": "Phone Number", "sTitle": "Phone Number" },
            { "title": "User ID", "sTitle": "User ID" },
			{ "title": "Invoice No.", "sTitle": "Invoice No." },
            { "title": "Invoice Date", "sTitle": "Invoice Date" },
			{ "title": "Service Start Date", "sTitle": "Service Start Date" },
            { "title": "Service End Date", "sTitle": "Service End Date" }
        ]
}
