dataOld  = [ {
    Name: "G1004",
	Caption: "Basic Pie Chart",
	Titles: ['June 2019', 'May 2020', 'June 2020'],
	dataSet: [
		{
			label: 'Target ',
			data: [200, 40, 30],
		},
	]
}, 
 {
     Name: "G1005",    
     Caption: "Basic Pie Chart",
    Titles: ['June 2019', 'May 2020', 'June 2020'],
    dataSet: [
        {
            label: 'Value',
            data: [110, 150, 120],

        }
    ]
}]
DBConfig  = [ {
    Name: "InvoiceSummary",
    Type: ["Chart", "Table"],
    Default: "Chart",
    GraphType: ["pie"],
    Stacked: false,
    Export: true,
    Details: false,
    FirstTitle: "Types",
    Y2axis: false,
    Axis: ["y-axis-1", "y-axis-1", "y-axis-2"],
    xscaleLabel: false, xscaleLabelTxt: 'Months',
    y1scaleLabel: true, y1scaleLabelTxt: 'Values (M)',
    y2scaleLabel: true, y2caleLabelTxt: 'Achieved %',
    Caption: "Target Set vs Achieved",
    Titles: [],
    dataSet: [],
    TableColumns: [],
    TableData: []
}, 
 {
     Name: "PaymentSummary",
    Type: ["Chart", "Table"],
    Default: "Chart",
    GraphType: ["doughnut"],
    Stacked: false,
    Export: true,
    Details: false,
    FirstTitle: "Types",
    Y2axis: false,
    Axis: ["y-axis-1", "y-axis-1", "y-axis-2"],
    xscaleLabel: false, xscaleLabelTxt: 'Months',
    y1scaleLabel: true, y1scaleLabelTxt: 'Values (M)',
    y2scaleLabel: true, y2caleLabelTxt: 'Achieved %',
    Caption: "Target Set vs Achieved",
    Titles: [],
    dataSet: [],
    TableColumns: [],
    TableData: []
}]