{
    "Graph" : [{
        "Name": "InvoiceSummary",
        "Caption": "Current Year Invoice Summary",
        "Titles": ["June 2019", "May 2020", "June 2020"],
        "dataSet": [
            {
                "label": "Target",
                "data": [200, 40, 30]
            }
        ]
    },
    {
        "Name": "PaymentSummary",
        "Caption": "Payment Summary",
        "Titles": ["June 2019", "May 2020", "June 2020"],
        "dataSet": [
            {
                "label": "Value",
                "data": [110, 150, 120]
            }
        ]
    }],
        "Card" : [
            {
                "Name": "234112",
                "Code": "RaisedInvoice11",
                "Subtitle": "Raised Invoice",
                "Status": "Approved",
                "Value": "91%"
            },
            {
                "Name": "355322",
                "Code": "RaisedQuery",
                "Subtitle": "Raised Query",
                "Status": "Resolved",
                "Value": "81%"
            },
            {
                "Name": "123433",
                "Code": "PaymentStatus",
                "Subtitle": "Payment Status",
                "Status": "Progress33",
                "Value": "61%"
            },
            {
                "Name": "342344",
                "Code": "PendingRejectedInvoice",
                "Subtitle": "Pending/Rejected Invoice",
                "Status": "Progress44",
                "Value": "17%"
            }]
}