var Controller = {
    Action: "",
    Init: function () {
        this.InitControls("Login");  
    },

    /* HTML page request */
    loadPageContents: function () {
        $.ajax({
            type: "GET",
            url: "pages/default.html",
            dataType: 'html',
            success: function (data) {
                $(".login-sample-1").css("left", "-100%");
                $(".page-layout").html(data);
                VendorPortal.SetMenu();
                Users.LoadUser();
                Users.InitControls();
            },
            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
        
    },
    InitControls: function (page_name) {
        switch (page_name) {
            case "Login":
                if (typeof (Dashboard) == "undefined")
                    VendorPortal.CachedScript("js/Pages/Login.js").done(function (script, textStatus) {Login.Init(); });
                else
                    Login.Init();
                break;

            case "Dashboard":
                if (typeof (Dashboard) == "undefined") {
                    Controller.loadPageContents();
                    VendorPortal.CachedScript("js/Pages/Dashboard.js").done(function (script, textStatus) {
                        Dashboard.Init();
                    });
                } else {
                    Controller.loadPageContents();
                    Dashboard.Init();
                }
                break;

            case "Reports":
                if (typeof (Reports) == "undefined")
                    VendorPortal.CachedScript("js/Pages/Reports.js").done(function (script, textStatus) { Reports.Init(); });
                else
                    Reports.Init();
                break;

            case "Invoice":
                if (typeof (Invoice) == "undefined")
                    VendorPortal.CachedScript("js/Pages/Invoice.js").done(function (script, textStatus) { Invoice.Init(); });
                else
                    Invoice.Init();
                break;
            case "Query":
                if (typeof (Query) == "undefined")
                    VendorPortal.CachedScript("js/Pages/Query.js").done(function (script, textStatus) { Query.Init(); });
                else
                    Query.Init();
                break;
            default:
                alert("Dashboard default");
                break;
        }
    },

};

