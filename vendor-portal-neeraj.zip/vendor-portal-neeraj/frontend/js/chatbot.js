
var globalVariable = "";
var globalqueryarray=[]
var i = 1;
$(function () {
    $("#btnShowPopup").click(function () {
        var title = "Vendor Portal Bot";
        // var body = "Welcome to ASPSnippets.com";

        $("#MyPopup .modal-title").html(title);
        // $("#MyPopup .modal-body").html(body);
        $("#MyPopup").modal("show");
        $(".chat_box").css("right", "10px");

        (function ($) {
            $.ajax({
                url: 'http://localhost:3000/api/session',
                type: 'Get',
                success: function (result) {
                    sessionStorage.setItem('Sessionid', result.data.session_id)
                    send_msg('1')
                }
            })
        })($)
    });
    $(".modal").on("hidden.bs.modal", function () {
        $(".messages-list").html("");
        // $("#input-me").attr("autocomplete", "off");

    });
    $(".close").click(function () {
        globalVariable = "";
        globalqueryarray=[]
        $(".chat_box").css("right", "-360px");
        $('#input-me').val('')
        $(".messages-list").html("");

    })
    setInterval(function () {
        $(".chat_icon").css("animation", "shake-chat-icon");
    }, 500);
});
$('#input-me').keypress(function (e) {
    if (e.which == 13) {
        $('#click-me').click();
    }
});
function sendMessageToWatson(options,type,text) {
    var htm2 = '<div id="ok" style="margin-left:-14px" class="typing-indicator"><span class="messages-bot-icon"><img src="images/chat-icon.png"></span>Typing...<span></span<span></span></div>'
    $('.messages-list').append(htm2)
    $.ajax({
        url: 'http://localhost:3000/api/message',
        type: 'Post',
        data: { session_id: sessionStorage.getItem('Sessionid'), message: text ,data:options,type:type},
        success: function (result) {
            if (result && result[0].type &&result[0].type == 'query') {
                $('#ok').remove();

                result.forEach(element => {
                    if(element.response_type == "text"){

                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.text +'</span><div class="message-header"></div></p></li>'

                        $('.messages-list').append(html)

                    }

                    if(element.response_type == "option"){
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.title +'</span><div class="message-header"></div></p></li>'

                        $('.messages-list').append(html)
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                });
                globalVariable = 'query'
                console.log('global variable ',globalVariable)
                // raiseQuery()

            }
           else if (result && result[0].type &&result[0].type == 'problem') {
           
                result.forEach(element => {
                    $('#ok').remove();

                    if(element.response_type == "text"){
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.text +'</span><div class="message-header"></div></p></li>'

                        $('.messages-list').append(html)
                        // $('.chat_box').scrollTop($('.chat_box')[0].scrollHeight);
                    }

                    
                    if(element.response_type == "option"){
                        

                        $("#no").attr("disabled",false)
                        $("#yes").attr("disabled",false)
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.title +'</span><div class="message-header"><input type="button" id="yes' + i + '" class="btn btn-primary" value="I am not able to track my invoice" style="margin-top: 3px" onclick="problemCall(`I am not able to track my invoice`,'+i+' )"><input type="button" id="no' + i + '" class="btn btn-primary" style="margin-top: 3px" value="I am not able to track my query status" onclick="problemCall(`I am not able to track my query status`,'+i+')"></p> </div></p></div></p></li>'

                        $('.messages-list').append(html)
                       i++;
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                });
                globalVariable = 'problem'
                console.log('global variable ',globalVariable)
                // raiseQuery()

            }
            else if (result && result[0].type &&result[0].type == 'payment_issue') {
           
                result.forEach(element => {
                    $('#ok').remove();

                    if(element.response_type == "text"){
                        // var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.text +'</span><div class="message-header"></div></p></li>'

                        // $('.messages-list').append(html)
                        // $('.chat_box').scrollTop($('.chat_box')[0].scrollHeight);
                    }

                    
                    if(element.response_type == "option"){
                        

                        $("#no").attr("disabled",false)
                        $("#yes").attr("disabled",false)
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.title +'</span><div class="message-header"><input type="button" id="yes' + i + '" class="btn btn-primary" value="Show query status" style="margin-top: 3px" onclick="paymentCall(`Show query status`,'+i+' )"><input type="button" id="no' + i + '" class="btn btn-primary" style="margin-top: 3px" value="Show invoice status" onclick="paymentCall(`Show invoice status`,'+i+')"></p> </div></p></div></p></li>'

                        $('.messages-list').append(html)
                       i++;
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                });
                globalVariable = 'payment'
                console.log('global variable ',globalVariable)
                // raiseQuery()

            }
            else if (result && result[0].type &&result[0].type == 'query staus') {


               
                // globalVariable = 'query status'
                Status(result,'Query',80)
                // raiseQuery()

            }
            else if (result && result[0].type &&result[0].type == 'invoice status') {


               
                // globalVariable = 'query status'
                invoiceStatus(result,'RaiseInvoice',79)
                // raiseQuery()

            }
            else if (result && result[0].type &&result[0].type == 'another query status') {


               console.log('------- line 123')
                globalVariable = 'another query status'
                // if(type == 'another_query'){
                //     console.log('------- line 126')

                // anotherQueryStatus(result,'RaiseQuery',80, text)

                // }
                // else {
                    console.log('=======132')
                    result.forEach(element => {
                        $('#ok').remove();

                        if(element.response_type == "text"){
    
                            var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + element.text +'</span><div class="message-header"></div></p></li>'

                            $('.messages-list').append(html)
                        }
                        if(element.response_type == "option"){
                            var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'+ element.title + '</span><div class="message-header"><input type="button" id="yes' + i + '" class="btn btn-primary" value="Yes" onclick="callYes('+ i +')"><input type="button" id="no' + i + '" style="margin-left: 4px" class="btn btn-primary" value="no" onclick="callNo('+ i +')"></div></p></li>'
                        $('.messages-list').append(html)
                        }
                        $('.list-unstyled').animate({
                            scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                    });

                    i++;
                // }
                // console.log('global variable ',globalVariable)
                // raiseQuery()

            }
            else if (result && result[0].type &&result[0].type == 'another invoice status') {


               
                globalVariable = 'another invoice status'
                // if(type == 'another_invoice'){
                //     anotherInvoiceStatus(result,'RaiseInvoice',80, text)

                // }
                // else {
                    result.forEach(element => {
                        $('#ok').remove();

                        if(element.response_type == "text"){
    
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.text +'</span><div class="message-header"></div></p></li>'

                        $('.messages-list').append(html)
                        }
                        if(element.response_type == "option"){
                            var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title + '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" value="Yes" onclick="callYes('+i+')"><input type="button" id="no'+i+'" style="margin-left: 4px" class="btn btn-primary" value="No" onclick="callNo('+i+')"></div></p></li>'
                        $('.messages-list').append(html)
                        }
                        $('.list-unstyled').animate({
                            scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                    });
                    i++
                // }
                // console.log('global variable ',globalVariable)
                // raiseQuery()

            }

          else if(result && result[0].type &&result[0].type == 'query id received')
          {
             result.forEach(element => {
                $('#ok').remove();

                    if(element.response_type=='text')
                    {

                        let splitted_data_element=element.text.split('/n')
                        console.log(splitted_data_element,'splitted_data_element',globalqueryarray)
                       let html_text= splitted_data_element[0]+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][1]+'-'+'<strong>'+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][3]+'</strong>'+splitted_data_element[2]+'<strong>'+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][4]+'</strong>'+splitted_data_element[4]+'<strong>'+(globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][6] ? globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][6]: "NA")+'</strong>'
                       var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + html_text +'</span><div class="message-header"></div></p></li>'

                       $('.messages-list').append(html)
                    }
                    if(element.response_type=="option")
                    {
                        // let splitted_data_element=element.text.split('/n')
                    //     console.log()
                    //     console.log(splitted_data_element,'splitted_data_element',result)
                    //    let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][6]
                    var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of other query Id" onclick="queryCall(`Show status of other query Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="queryCall(`No i am done`,'+i+')"></div></p></li>'
                    $('.messages-list').append(html)
                    i++;
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                });
                globalqueryarray=[]
          }
          else if(result && result[0].type &&result[0].type == 'invoice id received')
          {
             result.forEach(element => {
                $('#ok').remove();

                    if(element.response_type=='text')
                    {

                        let splitted_data_element=element.text.split('/n')
                        console.log(splitted_data_element,'splitted_data_element',globalqueryarray)
                       let html_text= splitted_data_element[0]+'<strong>'+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][0]+'</strong>'+splitted_data_element[1]+'<strong>'+splitted_data_element[2]+'</strong>'+'<strong>'+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][2]+'</strong>'+splitted_data_element[3]+'<strong>'+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][1]+'</strong>'+splitted_data_element[5]+'<strong>'+globalqueryarray[0].dataSet[globalqueryarray[0].dataSet.length-1][5]+'</strong>'
                       var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + html_text +'</span><div class="message-header"></div></p></li>'

                       $('.messages-list').append(html)
                    }
                    if(element.response_type=="option")
                    {
                        // let splitted_data_element=element.text.split('/n')
                    //     console.log()
                    //     console.log(splitted_data_element,'splitted_data_element',result)
                    //    let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][6]
                    var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of another invoice Id" onclick="inVoiceCall(`Show status of other invoice Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="inVoiceCall(`No i am done`,'+i+')"></div></p></li>'
                    $('.messages-list').append(html)
                    i++;
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                });
                globalqueryarray=[]
          }
          else if(result && result[0].type &&result[0].type == 'error in query')
          {
            result.forEach(element => {
                $('#ok').remove();

                // if(element.response_type == "text"){

                // var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.text +'</span><div class="message-header"></div></p></li>'

                // $('.messages-list').append(html)
                // }
                if(element.response_type == "option"){
                    console.log(element.title,'element.title in query')
                    // var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title +'</p></li>'
                    // $('.messages-list').append(html)

                    var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of other query Id" onclick="queryCall(`Show status of other query Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="queryCall(`No i am done`,'+i+')"></div></p></li>'
                    $('.messages-list').append(html)
                   
                }
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                // $('.messages-box').scrollTop($('.messages-box')[0].scrollHeight);
            });
            i++
          }
          else if(result && result[0].type &&result[0].type == 'error in invoice')
          {
            result.forEach(element => {
                $('#ok').remove();

                // if(element.response_type == "text"){

                // var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.text +'</span><div class="message-header"></div></p></li>'

                // $('.messages-list').append(html)
                // }
                if(element.response_type == "option"){
                    console.log(element.title,'element.title in query')
                    // var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title +'</p></li>'
                    // $('.messages-list').append(html)

                    var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of another invoice Id" onclick="inVoiceCall(`Show status of other invoice Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="inVoiceCall(`No i am done`,'+i+')"></div></p></li>'
                    $('.messages-list').append(html)
                   
                }
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                // $('.messages-box').scrollTop($('.messages-box')[0].scrollHeight);
            });
            i++
          }
            else{
                console.log('pakka yaha aya hoga')
                // var showLoader = true
                // if(showLoader == true){
                    
                   

                // }
                result.forEach(element => {
                    $('#ok').remove();
                    // if(showLoader == true){
                        // var html = ''
                        // var html = '<div style="margin-left:-14px; display:none" class="typing-indicator"><span></span>Typing...<span></span<span></span></div>'
                        // $('.messages-list').append(html)    
                    // }




                    if(element.response_type == "text"){
                    
                    var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.text +'</span><div class="message-header"></div></p></li>'

                    $('.messages-list').append(html)
                    }
                    if(element.response_type == "option"){
                        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title + '</span><div class="message-header"><input type="button" id="yes'+i+'" style="margin-top: 3px" class="btn btn-primary" value="Yes" onclick="defaultYes(`yes`, '+i+')"><input type="button" id="no'+i+'" style="margin-left: 4px; margin-top: 3px" class="btn btn-primary" value="No" onclick="defaultNo(`no`,'+i+')"></div></p></li>'  
                    $('.messages-list').append(html)
                    i++;
                    }
                    $('.list-unstyled').animate({
                        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                    // $('.messages-box').scrollTop($('.messages-box')[0].scrollHeight);
                });
            }
        }
    })
}

function raiseQuery(text) {
    $.ajax({
        type: 'Post',
        url: 'http://104.211.76.58:9090/Toscana/api/query/workitem',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({
            "assignTo": 2,
            "createdBy": 91,
            "currQueue": "Raise Query",
            "email": "krishna.manohar@hcl.com",
            "introMode": "API",
            "lobID": 80,
            "phoneNo": "",
            "processID": 61,
            "queryDescription": text,
            "queueID": 1167,
            "refInvoiceNo": "INV000000118",
            "status": 133,
            "vendorId": 91,
            "vendorName": "vendor"
            }),
        success: function (result) {
            globalVariable=""
            sendMessageToWatson(result.wiNumber,'query','input taken from user')
            // sendMessageToWatson('query')
        }
    })
}
function Status(array,type,lobvalue) {
    $.ajax({
        type: 'Post',
        url: 'http://104.211.76.58:9090/Toscana/api/workitemlist',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({
            
                "criteria": {
                    "StartDate": "2021-03-01", 
                    "EndDate": "2021-03-05", 
                    "issueType": type,
                    "QueryNumber":""    
                },
                "lobValue": lobvalue,
                "userIndex": 91
                
            }),
        success: function (result) {
            globalVariable=""
            array.forEach(element => {
                $('#ok').remove();

                if(element.response_type=='text')
                {
                    let splitted_data_element=element.text.split('/n')
                    console.log()
                    console.log(splitted_data_element,'splitted_data_element',result.dataSet[0])
                   let html_text= splitted_data_element[0]+result.dataSet[0][1]+'-'+'<strong>'+result.dataSet[0][3]+'</strong>'+splitted_data_element[2]+'<strong>'+result.dataSet[0][4]+'</strong>'+splitted_data_element[4]+'<strong>'+(result.dataSet[0][6] ? result.dataSet[0][6]: "NA") +'</strong>'
                   var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + html_text +'</span><div class="message-header"></div></p></li>'

                   $('.messages-list').append(html)
                }
                if(element.response_type=="option")
                {
                    // let splitted_data_element=element.text.split('/n')
                //     console.log()
                //     console.log(splitted_data_element,'splitted_data_element',result)
                //    let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][6]
                var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of other query Id" onclick="queryCall(`Show status of other query Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="queryCall(`No i am done`,'+i+')"></div></p></li>'
                $('.messages-list').append(html)
                i++;
                }
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
            });
           
        }
    })
}
function invoiceStatus(array,type,lobvalue) {
    $.ajax({
        type: 'Post',
        url: 'http://104.211.76.58:9090/Toscana/api/workitemlist',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({
            
                "criteria": {
                    "StartDate": "2021-03-01", 
                    "EndDate": "2021-03-05", 
                    "issueType": type,
                    "QueryNumber":""    
                },
                "lobValue": lobvalue,
                "userIndex": 91
                
            }),
        success: function (result) {
            globalVariable=""
            array.forEach(element => {
                $('#ok').remove();

                if(element.response_type=='text')
                {
                    let splitted_data_element=element.text.split('/n')
                    console.log()
                    console.log(splitted_data_element,'splitted_data_element',result)
                   let html_text= splitted_data_element[0]+'<strong>'+result.dataSet[result.dataSet.length-1][0]+'</strong>'+splitted_data_element[1]+'<strong>'+splitted_data_element[2]+'</strong>'+'<strong>'+result.dataSet[result.dataSet.length-1][2]+'</strong>'+splitted_data_element[3]+'<strong>'+result.dataSet[result.dataSet.length-1][1]+'</strong>'+splitted_data_element[5]+'<strong>'+result.dataSet[result.dataSet.length-1][5]+'</strong>'
                   var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + html_text +'</span><div class="message-header"></div></p></li>'

                   $('.messages-list').append(html)
                }
                if(element.response_type=="option")
                {
                    // let splitted_data_element=element.text.split('/n')
                //     console.log()
                //     console.log(splitted_data_element,'splitted_data_element',result)
                //    let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][6]
                var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of another invoice Id" onclick="inVoiceCall(`Show status of other invoice Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="inVoiceCall(`No i am done`,'+i+')"></div></p></li>'
                $('.messages-list').append(html)
                }
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
            });
           
        }
    })
}
function anotherQueryStatus(array,type,lobvalue, queryNumber) {
    $.ajax({
        type: 'Post',
        url: 'http://104.211.76.58:9090/Toscana/api/workitemlist',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({
            
                "criteria": {
                    // "StartDate": "2021-03-01", 
                    // "EndDate": "2021-03-05", 
                    "issueType": type,
                    "QueryNumber":queryNumber    
                },
                "lobValue": lobvalue,
                "userIndex": 91
                
            }),
        success: function (result) {
            globalVariable=""
             if(result.dataSet.length <= 0){
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                sendMessageToWatson('','error in query','error in query id')

               
             }
             else {
                globalqueryarray.push(result);
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                 sendMessageToWatson('','query id received','query id received')
                // array.forEach(element => {
                //     console.log('line- no. 369')
                //     if(element.response_type=='text')
                //     {
                //         let splitted_data_element=element.text.split('/n')
                //         console.log(splitted_data_element,'splitted_data_element',result)
                //        let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+(result.dataSet[result.dataSet.length-1][6] ? result.dataSet[result.dataSet.length-1][6]: "NA")
                //        var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + html_text +'</span><div class="message-header"></div></p></li>'

                //        $('.messages-list').append(html)
                //     }
                //     if(element.response_type=="option")
                //     {
                //         // let splitted_data_element=element.text.split('/n')
                //     //     console.log()
                //     //     console.log(splitted_data_element,'splitted_data_element',result)
                //     //    let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][6]
                //     var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + element.title+ '</span><div class="message-header"><input type="button" id="yes'+i+'" class="btn btn-primary" style="margin-top: 3px" value="Show status of another query Id" onclick="queryCall(`Show status of another query Id`,'+i+')"><input type="button" id="no'+i+'" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="queryCall(`No i am done`,'+i+')"></div></p></li>'
                //     $('.messages-list').append(html)
                //     i++;
                //     }
                //     $('.list-unstyled').animate({
                //         scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                // });
             }
            
           
        }
    })
}

function anotherInvoiceStatus(array,type,lobvalue, queryNumber) {
    $.ajax({
        type: 'Post',
        url: 'http://104.211.76.58:9090/Toscana/api/workitemlist',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({
            
                "criteria": {
                    // "StartDate": "2021-03-01", 
                    // "EndDate": "2021-03-05", 
                    "issueType": 'Invoice',
                    "QueryNumber":queryNumber    
                },
                "lobValue": 79,
                "userIndex": 91
                
            }),
        success: function (result) {
            globalVariable=""
             if(result.dataSet.length <= 0){
                // sendMessageToWatson('','','error in query id')
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                sendMessageToWatson('','error in invoice','error in invoice id')

                // var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' + 'Invoice Id not found' +'</span><div class="message-header"></div></p></li>'
                // $('.messages-list').append(html)
                // $('.list-unstyled').animate({
                //     scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
            }
             else {
                globalqueryarray.push(result);
                $('.list-unstyled').animate({
                    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                sendMessageToWatson('','received invoice id','received invoice id')
                // array.forEach(element => {
                //     if(element.response_type=='text')
                //     {
                //         let splitted_data_element=element.text.split('/n')
                //         console.log(splitted_data_element,'splitted_data_element',result)
                //         let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][0]+'-'+result.dataSet[result.dataSet.length-1][2]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][1]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][5]
                //         var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">'  + html_text +'</span><div class="message-header"></div></p></li>'

                //         $('.messages-list').append(html)
                //     }
                //     if(element.response_type=="option")
                //     {
                //         // let splitted_data_element=element.text.split('/n')
                //     //     console.log()
                //     //     console.log(splitted_data_element,'splitted_data_element',result)
                //     //    let html_text= splitted_data_element[0]+result.dataSet[result.dataSet.length-1][1]+'-'+result.dataSet[result.dataSet.length-1][3]+splitted_data_element[2]+result.dataSet[result.dataSet.length-1][4]+splitted_data_element[4]+result.dataSet[result.dataSet.length-1][6]
                //     var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/chat-icon.png"></span><span class="messages-bot">' +element.title+ '</span><div class="message-header"><input type="button" id="yes" class="btn btn-primary" style="margin-top: 3px" value="Show status of other invoice Id" onclick="inVoiceCall(`Show status of other invoice Id`)"><input type="button" id="no" class="btn btn-primary" style="margin-top: 3px" value="No i am done" onclick="inVoiceCall(`No i am done`)"></div></p></li>'
                //     $('.messages-list').append(html)
                //     }
                //     $('.list-unstyled').animate({
                //         scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
                // });
             }
            
           
        }
    })
}
function send_msg(defaultInput) {
    console.log(globalVariable,'window.globalVariable')
    var text = $('#input-me').val()
    console.log(text, 'inputvalue')
    if (/^\s*$/.test(text) &&  defaultInput == '2') {
        return;
      }
    if (text == '') {
        // return
        sendMessageToWatson('','','')
    }
    else {
        $('.list-unstyled').animate({
            scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");


        if (text) {

            var html = '<li class="msg-user clearfix"><p><span class="messages-user-icon"><img src="images/chat-user.png"></span><span class="messages-user">' + text +'</span><div class= "message-header"></div></p></li>'
            // var html = '<li class="messages-me clearfix"><div class= "message-header"><strong class="messages-title">Me</strong><small class="text-messages text-muted"></small></div><p class="messages-p">'+text+'</p>'

            $('.messages-list').append(html)
            $('#input-me').val('')
            
            if (globalVariable == 'query') {
                raiseQuery(text)
                // sendMessageToWatson('query')
            }
        
            else if (globalVariable == 'another query status') {
                anotherQueryStatus('','RaiseQuery',80,text)
                // sendMessageToWatson('query')
            }
            else if (globalVariable == 'another invoice status') {
                // sendMessageToWatson('','another_invoice',text)
                // sendMessageToWatson('query')
             anotherInvoiceStatus('','RaiseInvoice',80, text)

            }
            else{

            sendMessageToWatson('','',text)
           
            }
        }
    }

}


function callYes() {
    // console.log(i,'callyes')
    // $("#yes" +i ).attr("disabled",true)
    // $("#no" +i).attr("disabled",true)
    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
    // var value = $('#yes'+i).val()
    var value = $('#yes').val()
    console.log('valueeeeeee', value)
    if(value == 'Yes'){
        var text = "yes"

    }
    sendMessageToWatson('', '', text)

}
function defaultYes(value,i){
    console.log('valueeee', value)
    $('#yes'+i).attr("disabled", true);
    $("#no" +i).attr("disabled",true)
    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
     
    sendMessageToWatson('', '', value)
}
function callNo(i) {
    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
    // console.log('iiiiiiii', i)
    // $("#yes" +i ).attr("disabled",true)
    // $("#no" +i).attr("disabled",true)

    // var value = $('#no'+i).val()
    // console.log(value)
    // sendMessageToWatson('', 'another query', value)
    var value = $('#no').val()
    if(value == "No"){
        var text = "no"
    }
    sendMessageToWatson('', '', text)

}
function defaultNo(value,i){
    $('#yes'+i).attr("disabled", true);
    $("#no" +i).attr("disabled",true)
    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
    sendMessageToWatson('', '', value)

}
function queryCall(value,i){
      console.log('value<<>>>>>', value)
      $('#yes'+i).attr("disabled", true);
      $("#no" +i).attr("disabled",true)
      $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
    //   $('#no').prop("disabled", false);
    //   $('#yes').prop("disabled", false);
    if(value == 'No i am done'){
        console.log('yaha aya???')
       


        sendMessageToWatson('', '', value)
        // $('#yes').attr("disabled", true);
        // $('#no').attr("disabled", true);
    }
    else{
        console.log('ki yaha aya???')

       
        sendMessageToWatson('', 'another query', value)
        // $('#yes').attr("disabled", true);
        // $('#no').attr("disabled", true);
    }

}
function problemCall(value,i){
    $("#yes" +i ).attr("disabled",true)
    $("#no" +i).attr("disabled",true)

    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
        if(value == 'I am not able to track my invoice'){
        
            globalVariable = 'another invoice status'
        }
         if(value == 'I am not able to track my query status'){
            globalVariable = 'another query status'
        }
            sendMessageToWatson('', '', value)

        
}
function paymentCall(value,i){
    $("#yes" +i ).attr("disabled",true)
    $("#no" +i).attr("disabled",true)

    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
        if(value == 'Show invoice status'){
        
            globalVariable = 'another invoice status'
        }
         if(value == 'Show query status'){
            globalVariable = 'another query status'
        }
            sendMessageToWatson('', '', value)

        
}
function inVoiceCall(value,i){
    $("#yes" +i ).attr("disabled",true)
    $("#no" +i).attr("disabled",true)
    $('.list-unstyled').animate({
    scrollTop: $('.list-unstyled')[0].scrollHeight}, "fast");
    if(value == 'No i am done'){
        sendMessageToWatson('', '', value)
    }
    else{
        sendMessageToWatson('', 'another invoice', value)

    }

}