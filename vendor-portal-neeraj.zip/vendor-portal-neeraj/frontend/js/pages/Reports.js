﻿var Reports = {
    Init: function () {
        this.SetPage();
    },

    /* HTML page request */
    SetPage: function () {
        $.ajax({
            type: "GET",
            url: "pages/reports.html",
            dataType: 'html',
            success: function (data) {
                $(".content-area").html('');
                $(".content-area").html(data);
                Reports.InitControls();
            },
            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    /* API to get data reports*/
    GetData: function () {
        VendorPortal.GetDate();
        var FilterJSON = {
            lobValue: ($("#ddlReportType").val()=="Invoice")?Users.CurrentUser.process[0].LobID:Users.CurrentUser.process[1].LobID,
            userIndex: Users.CurrentUser.UserIndex,
            criteria: {
                StartDate: VendorPortal.startDate,//$("#txtStartDate").val(),
                EndDate: VendorPortal.endDate,//$("#txtEndDate").val(),
                issueType: $("#ddlReportType").val(), //report type
            }
        };
        console.log(FilterJSON);
        $.ajax({
            type: "POST",
            //url: "js/dummy-data/ReportData.js",
            url:"http://104.211.76.58:9090/Toscana/api/workitemlist",
            dataType: 'json',
            data: JSON.stringify(FilterJSON),
            contentType:'application/json',
            success: function (data) {
                $(".reports-table").show(); 
                VendorPortal.ColumnHeading = data.ColumnHeading;
                VendorPortal.dataSet = data.dataSet;
                VendorPortal.PlotData();
            },

            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    InitControls: function () {
        $("#txtStartDate").val('');
        $("#txtEndDate").val('');
        $("#btnSearch").unbind();
        $("#btnSearch").click(function () {
            if (VendorPortal.Validation()) {
                Reports.GetData();
            }
        });
    }

}