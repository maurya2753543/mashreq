﻿var Query = {
    Init: function () {
        this.SetPage();
        this.GetData();
    },

    /* HTML page request */
    SetPage: function () {
        $.ajax({
            type: "GET",
            url: "pages/query.html",
            dataType: 'html',
            success: function (data) {
                $(".login-sample-1").css("left", "-100%");
                $(".content-area").html('');
                $(".content-area").html(data);
                Query.InitControls();
            },
            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    SetData: function () {
         Query.RaiseQueryJSON = {
            assignTo:2,
            status:Users.CurrentUser.process[1].StatusID,
            vendorName:Users.CurrentUser.UserName,
            vendorId:Users.CurrentUser.UserIndex,
            queryDescription:$("#txtQuery").val(),
            refInvoiceNo:$("#txtRefInvoiceNo").val(),
            email:Users.CurrentUser.EmailID,
            phoneNo:Users.CurrentUser.phoneNo,
            introMode:"API",
            currQueue:"Raise Query",
            lobID:Users.CurrentUser.process[1].LobID,
            processID:Users.CurrentUser.process[1].ProcessID,
            createdBy:Users.CurrentUser.UserIndex,
            queueID:Users.CurrentUser.process[1].QueueID
            
            //Name: $("#txtName").val(),
            //Email: $("#txtEmail").val(),
            //PhoneNumber: $("#txtPhnNumber").val(),
            //UserId: $("#txtUserId").val(),
            //StartDate: $("#txtStartDate").val(),
            //EndDate: $("#txtEndDate").val(),
            //QueryNumber: $("#txtQueryNum").val()
        }
    },
    /* API to save data raise query*/
    SaveData: function () {
        console.log(Query.RaiseQueryJSON);
        $.ajax({
            type: "POST",
            //url: "js/dummy-data/QueryData.js",
            url:"http://104.211.76.58:9090/Toscana/api/query/workitem",
            dataType: 'json',
            data: JSON.stringify(Query.RaiseQueryJSON),
            contentType: 'application/json',
            success: function (data) {
                $(".raise-query").hide();
                $(".track-query").show();
                $("#txtStartDate").val('');
                $("#txtEndDate").val('');
                Query.GetData();
            },

            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    /* API to get data raise query*/
    GetData: function () {
        VendorPortal.GetDate();
        var FilterJSON = {
           // StartDate: VendorPortal.startDate,
           // EndDate: VendorPortal.endDate,
           // QueryNumber: $("#txtQueryNum").val()
           lobValue: Users.CurrentUser.process[1].LobID,
           userIndex: Users.CurrentUser.UserIndex,
           criteria: {
               StartDate: VendorPortal.startDate,
               EndDate: VendorPortal.endDate,
               issueType:"RaiseQuery",
               QueryNumber: $("#txtQueryNum").val()
           }
        };
        $.ajax({
            type: "POST",
            //url: "js/dummy-data/QueryData.js?id=" + Math.random(),
            url: "http://104.211.76.58:9090/Toscana/api/workitemlist",
            dataType: 'json',
            data: JSON.stringify(FilterJSON),
            contentType: 'application/json',
            success: function (data) {
                VendorPortal.ColumnHeading = data.ColumnHeading;
                VendorPortal.dataSet = data.dataSet;
                VendorPortal.PlotData();
            },

            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    InitControls: function () {
        $("#txtStartDate").val('');
        $("#txtEndDate").val('');
        $("#btnSubmit, #btnSearch, .advance-btn, .query-btn").unbind();
        $("#btnSubmit").click(function () {
            if (VendorPortal.Validation()) {
                Query.SetData();
                Query.SaveData();
            }
        });
        $("#btnSearch").click(function () {
            if (VendorPortal.Validation()) {
                Query.GetData();
            }
        });
        $(".advance-btn").click(function () {
            $(".advance-search").slideToggle();
        });
        $(".query-btn").click(function () {
            $(".raise-query").show();
            $(".track-query").hide();
        });
    }
}