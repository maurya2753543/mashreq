﻿var Invoice = {
     
    Init: function () {
        this.SetPage();
        this.GetData();
    },

    /* HTML page request */
    SetPage: function () {
        $.ajax({
            type: "GET",
            url: "pages/invoice.html",
            dataType: 'html',
            success: function (data) {
                $(".content-area").html('');
                $(".content-area").html(data);
                Invoice.InitControls();
            },
            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    SetData: function () {
        Invoice.RaiseInvoiceJSON = {
            vendorName: Users.CurrentUser.UserName,
            email: Users.CurrentUser.EmailID,
            //phoneNo: $("#txtServiceStartDate").val(),
            vendorId: Users.CurrentUser.UserIndex,
            //invoiceNo: "",
            //invoiceDate: "",
            invoiceAmount: $("#txtAmount").val(),
            serviceStartDate: $("#txtServiceStartDate").val(),
            serviceEndDate: $("#txtServiceEndDate").val(),
            assignTo: 2,
            status: Users.CurrentUser.process[0].StatusID,
            vendorRemarks: $("#txtRemarks").val(),
            introMode: "API",
            //introDate: "2021-02-11 11:31:40",
            currQueue: "Raise Invoice",
            lobID: Users.CurrentUser.process[0].LobID,
            processID: Users.CurrentUser.process[0].ProcessID,
            createdBy: Users.CurrentUser.UserIndex,
            queueID: Users.CurrentUser.process[0].QueueID
        };
    },

    /* API to save data raise invoice*/
    SaveData: function () {
        console.log(Invoice.RaiseInvoiceJSON);
        $.ajax({
            type: "POST",
            //url: "js/dummy-data/InvoiceData.js",
            url: "http://104.211.76.58:9090/Toscana/api/workitem?tbl="+Users.CurrentUser.process[0].TableName,
            dataType: 'json',
            data: JSON.stringify(Invoice.RaiseInvoiceJSON),
            contentType: 'application/json',
            success: function (data) {
                console.log(data);
                Invoice.UploadFile(data);
                $("#txtServiceStartDate").val('');
                $("#txtServiceEndDate").val('');
                //--clear advance search fields
                $(".raise-invoice").hide();
                $(".track-invoice").show();
                alert("Invoice Raised with RowId - "+data.rowID)
                Invoice.GetData();
                
            },

            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    /* API to get data raise invoice*/
    GetData: function () {
        VendorPortal.GetDate();
        var FilterJSON = {
            lobValue: Users.CurrentUser.process[0].LobID,
            userIndex: Users.CurrentUser.UserIndex,
            criteria: {
                StartDate: VendorPortal.startDate,
                EndDate: VendorPortal.endDate,
                issueType:"Invoice",
                QueryNumber: $("#InvoiceNo").val()
            }
        };
        $.ajax({
            type: "POST",
            //url: "js/dummy-data/InvoiceData.js",
            url: "http://104.211.76.58:9090/Toscana/api/workitemlist",
            dataType: 'json',
            data: JSON.stringify(FilterJSON),
            contentType: 'application/json',
            success: function (data) {
                if (data.ColumnHeading.length > 0) {
                    VendorPortal.ColumnHeading = data.ColumnHeading;
                    VendorPortal.dataSet = data.dataSet;
                    VendorPortal.PlotData();
                } else {

                }
                
            },

            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

     /* API to upload a file*/
     UploadFile: function (data) {
        console.log(data);
        var formData = new FormData();
        formData.append("file", document.getElementById("uploadPDF").files[0]);
        var lobId = Users.CurrentUser.process[0].LobID;
        var rowId = data.rowID;
        if(document.getElementById("uploadPDF").files[0]==undefined){
            return;
        }

        $.ajax({
            type: "POST",
            //url: "js/dummy-data/QueryData.js?id=" + Math.random(),
            url: "http://104.211.76.58:9090/Toscana/api/uploadFile?lobID="+lobId+"&rowID="+rowId+"&fileName=InvoiceFile.pdf",
            async: true,
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            timeout: 10000,
            success: function (data) {
                //alert('1');
            },

            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    InitControls: function () {
        $("#txtStartDate").val('');
        $("#txtEndDate").val('');
        $("#txtName").val(Users.CurrentUser.PersonalName);
        $("#txtEmail").val(Users.CurrentUser.EmailID);
        $("#txtPhnNumber").val('');
        $("#txtUserId").val(Users.CurrentUser.UserIndex);
        $("#txtInvoiceNo").val('');
        $("#txtInvoiceDate").val('');
        $("#txtAmount").val('');
       
        $("#btnSubmit, #btnSearch, .advance-btn, .invoice-btn").unbind();
        $("#btnSubmit").click(function () {
            if (VendorPortal.Validation()) {
                  Invoice.SetData();
                  Invoice.SaveData();
                  //Invoice.UploadFile();
            }
        });
        $("#btnSearch").click(function () {
            if (VendorPortal.Validation()) {
                Invoice.GetData();
            }
        });
        $(".advance-btn").click(function () {
            $(".advance-search").slideToggle();
        });
        $(".invoice-btn").click(function () {
            $(".raise-invoice").show();
            $(".track-invoice").hide();
        });
    }


}