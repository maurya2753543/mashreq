﻿var Login = {
    Init: function () {
        this.InitControls();
    },

    InitControls: function () {
        if (typeof (Users) == "undefined")
            VendorPortal.CachedScript("js/Pages/Users.js").done(function (script, textStatus) { Users.Init(); });
        else
            Users.Init();
    },

}