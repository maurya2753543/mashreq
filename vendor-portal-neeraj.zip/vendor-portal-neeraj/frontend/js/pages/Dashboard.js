﻿// Dashboard
var data = [];

var Dashboard = {
    Init: function () {
        this.SetPage();
    },

    /* HTML page request */
    SetPage: function () {
        $.ajax({
            type: "GET",
            url: "pages/dashboard.html?id=" + Math.random(),
            dataType: 'html',
            success: function (data) {
                $(".content-area").html('');
                $(".content-area").html(data);
                Dashboard.InitControls();
                Dashboard.GetData();
            },
            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    /* API to get data for dashboard */
    GetData: function () {
        $.ajax({
            type: "GET",
            url: "js/dummy-data/VendorData.js?id=" + Math.random(),
            //api to 
            dataType: 'json',
            success: function (_data) {
                var Icon_Arr = ["fa-user", "fa-suitcase", "fa-commenting", "fa-file"];
                $(".card-group").html('');
                for (var i = 0; i < _data.Card.length; i++) {
                    $(".card-group").append('\
                        <div class="card">\
                        <div class="card-body">\
                        <div class="row">\
                            <div class="col-12">\
                                <div class="float-right">\
                                <i class="f30 opacity-3 fa '+Icon_Arr[i]+'"></i>\
                                </div>\
                                <h3 class="text-success">'+ _data.Card[i].Name + '</h3>\
                                <p class="card-subtitle text-muted fw-500">'+ _data.Card[i].Subtitle + '</p>\
                            </div>\
                            <div class="col-12">\
                                <div class="progress mt-3 mb-1" style="height: 6px;">\
                                    <div class="progress-bar bg-success" role="progressbar" style="width:'+ _data.Card[i].Value + '" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>\
                                </div>\
                                <div class="text-muted f12">\
                                    <span>'+ _data.Card[i].Status + '</span>\
                                    <span class="float-right">'+ _data.Card[i].Value + '</span>\
                                </div>\
                            </div>\
                        </div>\
                        </div>\
                        </div>\
                    ');
                }
                data = _data.Graph;
                VendorPortal_Chart.Init();
            },
            error: function (jqXHR, exception) {
                VendorPortal.ThrowErrors(jqXHR, exception);
            }
        });
    },

    InitControls: function () {
        $("icon_menu").unbind();
        $(".icon_menu").click(function () {
            $('.down_menu').css('display', 'none');
            if ($(window).width() > 991) {
                $('body').toggleClass("nav_small");
            } else {
                $('body').toggleClass("mobile_nav");
            }
        });
        $(window).on('resize', function () {
            $('body').removeClass("nav_small");
        })
    }


}