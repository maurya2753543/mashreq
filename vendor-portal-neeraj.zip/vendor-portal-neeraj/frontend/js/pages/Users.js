﻿var Users = {

    Init: function () {
        this.InitControls();
    },

    /* API to get data for user */
    ValidateUser: function () {
        // alert('hello')
        if (VendorPortal.Validation("login-field")) {

            var userInitJSON = {
                "username": $("#UserID").val(),
                "password": $("#password").val()
            };

            $.ajax({
                type: "POST",
                //url: "js/Users.js",
                url: "http://104.211.76.58:9090/Toscana/api/validate",
                dataType: 'json',
                data: JSON.stringify(userInitJSON),
                contentType: 'application/json',
                success: function (result) {
                    console.log(result);
                    if (result.result == 1) {
                        Users.CurrentUser = result.data;
                        Controller.InitControls("Dashboard");
                    } else {
                        alert(result.msg);
                    }
                    /*
                     * var result = {
                        "UserData": {
                            "UserID": "mrinal.singh@hcl.com",
                            "password": "MRINAL",
                            "UserName": "Mrinal Singh",
                            "UserImg": "",
                            "Role": "admin",
                            "valid": "",
                            "Notification": "",
                        },
                        "Authentication": true,

                        // false case
                         *//*"UserData": {
                            "reason": "Username and Password did not matched, Please enter the correct username and password.",
                        },
                        "Authentication": false*//*
                         
                    };
                    var success = result.Authentication;

                    if (success) {
                        Users.CurrentUser = result.UserData;
                        Controller.InitControls("Dashboard");
                    } else {
                        alert(result.UserData.reason)
                    }*/

                },

                error: function (jqXHR, exception) {
                    VendorPortal.ThrowErrors(jqXHR, exception);
                }
            });

        }
    },

    LoadUser: function () {
        $(".img-circle").attr('src', Users.CurrentUser.UserImg);
        $(".info p").html(Users.CurrentUser.UserName);
    },

    Logout: function () {
        Users.CurrentUser = null
    },

    /* API to get data for forgot password */
    ForgotPassword: function () {
        if (VendorPortal.Validation("forgot-field")) {
            var userInitJSON = {
                "UserId": $("#forgot_pass").val()
            };

            $.ajax({
                type: "get",
                url: "js/Users.js",
                dataType: 'json',
                data: JSON.stringify(userInitJSON),
                success: function (result) {
                    var result = { "Status": "OK" }

                    if (result.Status == "OK") {
                        alert("Your login password is sent to your registered Email ID.");
                        $(".forgot-pass-cnt").hide();
                        $(".login-cnt").show();
                    } else {
                        alert("This Email ID is not registered with us. Kindly try again with the correct Email ID.")
                    }

                },
                error: function (jqXHR, exception) {
                    VendorPortal.ThrowErrors(jqXHR, exception);
                }
            });
        
        }
        
    },

    InitControls: function () {
        $("#login, #forget_pass, .logout").unbind();
        $("#login").click(function () {
            // alert('login clicked')
            Users.ValidateUser();
        });

        $("#forget_pass").click(function () {
            Users.ForgotPassword();
        });

        $(".logout").click(function () {
            Users.Logout();
            $(".login-sample-1").css("left", "0");
            $(".page-layout").html('');
            $("#UserID").val('');
            $("#password").val('');
            VendorPortal.MsgAlert("Logout Successfully", "alert-success alert");
        });
    }
}