﻿$(function () {
    VendorPortal.Init();
})

var VendorPortal = {
    Init: function () {
        this.InitController();
    },

    CachedScript: function (url, options) {
        options = $.extend(options || {}, {
            dataType: "script",
            cache: true,
            url: url
        });
        return jQuery.ajax(options);
    },

    LoadStyleSheet: function (file, _id) {
        var cssLink = $("<link>");
        $("head").append(cssLink); //IE hack: append before setting href
        cssLink.attr({
            rel: "stylesheet",
            type: "text/css",
            id: _id,
            href: file
        });
    },

    InitController: function (action) {
        if (typeof (Controller) == "undefined")
            this.CachedScript("js/Controller.js").done(function (script, textStatus) { Controller.Init(action); });
        else
            Controller.Init(action);

        $(".forgot-password, .back-login").unbind();
        $(".forgot-password").click(function () {
            $(".login-cnt").hide();
            $(".forgot-pass-cnt").show();
        });
        $(".back-login").click(function () {
            $(".login-cnt").show();
            $(".forgot-pass-cnt").hide();
        });
    },

    SetMenu: function () {
        $(".menu-item").unbind();
        $(".menu-item").click(function () {
            var data_menu = $(this).attr("data-menu");
            $(".page-breadcrumb h1").html($(this).attr("data-label"));
            $(".breadcrumb li:last-child").html($(this).attr("data-label"));
            Controller.InitControls(data_menu);
        });
    },

    Validation: function () {
        var check_query = true;
        for (var i = 0; i < $(".required").length; i++) {
            var required = "#" + $(".required")[i].id;
            if ($(required).is(':visible')) {
                if ($(required).val() == "" || $(required).val() == "0") {
                    $(required).css("border-color", "#ff6173");
                    $(".form-control-file" + required).css("color", "#ff6173");
                    check_query = false;
                } else {
                    $(required).css("border-color", "#e5e9ec");
                    $(".form-control-file" + required).css("color", "#53505f");
                }
            }
        }
        return check_query;
    },

    MsgAlert: function (msg, type) {
        $(".custom-alert").css("top", "3%");
        $("#alert").addClass(type);
        $(".alert-msg").html(msg);
        setTimeout(function () { $(".custom-alert").css("top", "-50%");}, 3000);
    },

    ThrowErrors: function (jqXHR, exception) {
        if (jqXHR.status === 0)
            VendorPortal.MsgAlert('Not connected to Server.\n Please Check your Network.', "alert-danger alert");
        else if (jqXHR.status == 404)
            VendorPortal.MsgAlert('Requested page not found.', "alert-danger alert");
        else if (jqXHR.status == 500)
            VendorPortal.MsgAlert('Internal Server Error. Please contact your administrator.', "alert-danger alert");
        else if (exception === 'parsererror')
            VendorPortal.MsgAlert('Requested data parsing failed.', "alert-danger alert");
        else if (exception === 'timeout')
            VendorPortal.MsgAlert('Session Time out error.', "alert-danger alert");
        else if (exception === 'abort')
            VendorPortal.MsgAlert('Ajax request aborted.', "alert-danger alert");
        else
            $.reportAlert('Uncaught Error.\n' + jqXHR.responseText);
    },

    PlotData: function () {
        $("#dtTable").html("");
        $("#dtTable").append('<table id="tblVendor" class="table table-bordered" width="100%"></table>');
        $('#tblVendor').DataTable({
            data: JSON.parse(JSON.stringify(VendorPortal.dataSet)) /*dataSet*/,
            destroy: true,
            "columnDefs": [{ "width": "20%", "width": "4%", "width": "4%", "width": "4%", "width": "4%", "width": "4%" }],
            responsive: true,
            "ordering": true,
            "paging": true,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "searching": false,
            "autoWidth": true,
            columns: JSON.parse(JSON.stringify(VendorPortal.ColumnHeading)),
            "fnRowCallback": function (nRow, aData, iDisplayIndex) {
            },
            "initComplete": function (settings, json) {
            }
        })

    },

    GetDate: function () {
        var d = new Date();
        VendorPortal.startDate = $("#txtStartDate").val();
        VendorPortal.endDate = $("#txtEndDate").val();

        if (VendorPortal.endDate == "" || VendorPortal.endDate == undefined) {
            //VendorPortal.endDate = d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
            VendorPortal.endDate = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
        }
        if (VendorPortal.startDate == "" || VendorPortal.startDate == undefined) {
            d.setMonth(d.getMonth() - 3);
            //VendorPortal.startDate = "01/" + (d.getMonth() + 1) + "/" + d.getFullYear();
            VendorPortal.startDate = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
        }
    },

    
}

