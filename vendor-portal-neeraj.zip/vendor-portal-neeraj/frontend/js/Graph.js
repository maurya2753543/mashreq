﻿
var VendorPortal_Chart = {

    Init: function () {
            this.Colors = ['#003f5c', '#2f4b7c', '#665191', '#a05195', '#665191', '#d45087', '#f95d6a', '#ff7c43', '#ffa600'],
            this.borderColor = ['#2196f3', '#ff9800', "#665191", '#003f5c', '#2f4b7c', '#f53794', '#a05195', '#665191', '#d45087', '#f95d6a', '#ff7c43', '#ffa600'],
            this.backgroundColor = ['#2196f3', '#ff9800', "#665191", '#003f5c', '#2f4b7c', '#f53794', '#a05195', '#665191', '#d45087', '#f95d6a', '#ff7c43', '#ffa600'],
            this.hoverborderColor = ['#2196f3', '#ff9800', "#665191", '#003f5c', '#2f4b7c', '#f53794', '#a05195', '#665191', '#d45087', '#f95d6a', '#ff7c43', '#ffa600'],
            this.hoverBackgroundColor = ['#2196f3', '#ff9800', "#665191", '#003f5c', '#2f4b7c', '#f53794', '#a05195', '#665191', '#d45087', '#f95d6a', '#ff7c43', '#ffa600'],
            this.data = [];
        this.InitPage();
    },

    InitPage: function () {
        try {
            var ConfigData = JSON.parse(JSON.stringify(DBConfig)); //
            for (var i = 0; i < data.length; i++) {
                var name = data[i].Name;
                $("#t_" + data[i].Name).html(data[i].Caption);
                $($("#t_" + data[i].Name).parents(".mycard")).show();
                var tmpData = jQuery.grep(ConfigData, function (d) { return (d.Name == data[i].Name); });
                if (tmpData.length > 0) {
                    tmpData[0].labels = data[i].Titles;
                    tmpData[0].TableColumns.push({ title: tmpData[0].FirstTitle, "width": "150px", });
                    for (var j = 0; j < data[i].dataSet.length; j++) {
                        data[i].dataSet[j].type = tmpData[0].GraphType[j];
                        if (tmpData[0].GraphType[0] == "pie" || tmpData[0].GraphType[0] == "doughnut")
                            data[i].dataSet[j].backgroundColor = VendorPortal_Chart.backgroundColor;
                        else
                            data[i].dataSet[j].borderColor = VendorPortal_Chart.borderColor[j],
                            data[i].dataSet[j].backgroundColor = VendorPortal_Chart.backgroundColor[j],
                            data[i].dataSet[j].hoverborderColor = VendorPortal_Chart.hoverborderColor[j],
                                data[i].dataSet[j].hoverBackgroundColor = VendorPortal_Chart.hoverBackgroundColor[j];

                        if (tmpData[0].Y2axis)
                            data[i].dataSet[j].yAxisID = tmpData[0].Axis[j];

                        tmpData[0].dataSet.push(data[i].dataSet);

                        var _data = JSON.parse(JSON.stringify(data[i].dataSet[j].data));
                        tmpData[0].TableData.push(_data);
                        tmpData[0].TableData[j].splice(0, 0, data[i].dataSet[j].label);
                    }
                    for (var j = 0; j < data[i].Titles.length; j++) {
                        var t = {};
                        t.title = data[i].Titles[j];
                        tmpData[0].TableColumns.push(t);
                    }
                    VendorPortal_Chart.data.push(tmpData[0]);
                    for (var j = 0; j < tmpData[0].Type.length; j++) {
                        switch (tmpData[0].Type[j]) {
                            case "Chart":
                                VendorPortal_Chart.PlotGraph(name);
                                break;
                            case "Table":
                                VendorPortal_Chart.PlotTable(name);
                                break;
                        }
                    }
                }
            }
            this.InitControls();
        } catch (err) {

        }
    },

    InitControls: function () {
        try {

            $(".dataView").click(function () {
                var myCard = $(this),
                    myCardParent = $(myCard.parents(".card")),
                    chartViewBtn = $(myCard).parent().children(".chartView"),
                    chartView = $(myCardParent).children(".card-body").children(".chartViewC"),
                    dataView = $(myCardParent).children(".card-body").children(".dataViewC");
                
                dataView.addClass("show");
                VendorPortal_Chart.PlotTable(myCardParent.children(".card-body").attr("id").split("_")[1]);
                chartView.removeClass("show");
                $(myCard).hide(), $(chartViewBtn).show();
                $(myCard.parents(".card-header-right")).children(".dt-buttons").show();
            });

            $(".chartView").click(function () {
                var myCard = $(this),
                    myCardParent = $(myCard.parents(".card")),
                    dataViewBtn = $(myCard).parent().children(".dataView"),
                    chartView = $(myCardParent).children(".card-body").children(".chartViewC"),
                    dataView = $(myCardParent).children(".card-body").children(".dataViewC");
                dataView.removeClass("show");
                chartView.addClass("show");
                $(myCard).hide(), $(dataViewBtn).show();
                $(myCard.parents(".card-header-right")).children(".dt-buttons").hide();
            });

            $(".minimizecard").click(function () {
                var myCard = $(this),
                    myCardParent = $(myCard.parents(".mycard")),
                    fullBtn = $(myCard).parent().children(".fullcard");
                $(myCardParent).removeClass("col-xs-12 col-sm-12 col-lg-12"); 
                $(window).scrollTop(myCardParent.offset().top - 120);
                myCardParent.children().children(".card-body").attr("id")

                var c = myCardParent.children().children(".card-body").attr("id").split("_");
                if ($("#div_" + c[1]).is(":visible"))
                    VendorPortal_Chart.PlotTable(c[1]);
                $(myCard).hide(), $(fullBtn).show();
            });

            $(".fullcard").on("click", function () {
                var myCard = $(this),
                    myCardParent = $(myCard.parents(".mycard")),
                    minimizeBtn = $(myCard).parent().children(".minimizecard");
                $(myCardParent).addClass("col-xs-12 col-sm-12 col-lg-12");
                $(window).scrollTop(myCardParent.offset().top - 120);
                var c = myCardParent.children().children(".card-body").attr("id").split("_");
                if ($("#div_"+c[1]).is(":visible"))
                    VendorPortal_Chart.PlotTable(c[1]);
                $(myCard).hide(), $(minimizeBtn).show();
            })

        } catch (err) {

        }
    },

    InitContainer: function (obj, data, type) {
        try {
            var show = "";
            if (data.Type.length == 1)
                $("#d_" + obj).parent().find(".dataView").hide(), $("#d_" + obj).parent().find(".chartView").hide();

            switch (type) {
                case "Table":
                    if (data.Default == "Table")
                        show = "show",
                            $("#d_" + obj).parent().find(".dataView").hide();

                    if ($('#div_' + obj).length == 0)
                        $("#d_" + obj).append('<div id="div_' + obj + '" class="main-container dataViewC collapse ' + show + '">\
                                                <table id="tbl_' + obj + '" class="display table table-striped table-hover dt-responsive nowrap" style="max-width:100% !important" width="100%"></table>\
                                           </div> ');
                    break;
                case "Chart":
                    var show = "";
                    if (data.Default == "Chart")
                        show = "show",
                            $("#d_" + obj).parent().find(".chartView").hide();

                    if ($('#g_' + obj).length == 0)
                        $("#d_" + obj).append('<div id="g_' + obj + '" class="main-container chartViewC collapse ' + show + '">\
                                                <canvas id ="gph_' + obj + '" ></canvas>\
                                           </div>');
                    break;
            }
        } catch (err) {

        }
    },

    PlotGraph: function (obj) {
        try {

            var tmpData = jQuery.grep(VendorPortal_Chart.data, function (d) { return (d.Name == obj); });
            data.dataSet = tmpData[0].dataSet[0], stacked = tmpData[0].Stacked, Y2axis = tmpData[0].Y2axis;
            xscaleLabel = tmpData[0].xscaleLabel, xscaleLabelTxt = tmpData[0].xscaleLabelTxt,
            y1scaleLabel = tmpData[0].y1scaleLabel, y1scaleLabelTxt = tmpData[0].y1scaleLabelTxt,
            y2scaleLabel = tmpData[0].y2scaleLabel, y2caleLabelTxt = tmpData[0].y2caleLabelTxt,


            VendorPortal_Chart.InitContainer(obj, tmpData[0], "Chart");

            var ChartData = {
                labels: tmpData[0].labels,
                datasets: tmpData[0].dataSet[0],
            }

            var graphType = tmpData[0].GraphType[0];
            var ctx = document.getElementById("gph_" + obj).getContext('2d');
            obj = new Chart(ctx, {
                type: graphType,
                data: ChartData,
                options: VendorPortal_Chart.GraphOptions(graphType,ctx),
                plugins: [{
                    beforeInit: function (chart, options) {
                        //alert(1)
                    }
                }],
            });
        } catch (err) {

        }
    },

    GraphOptions: function (GraphType,ctx) {
        var options;
        switch (GraphType) {
            case "bar":
                options =
                {
                    responsive: true,
                    legend: {
                        position: 'top',
                        display: true,
                            labels: {
                            fontColor: 'rgb(255, 99, 132)'
                        },
                        //onClick: newLegendClickHandler,
                        legendCallback: function (chart) {
                            // Return the HTML string here.
                        }
                    },
                    scales: {
                        xAxes: [{
                            stacked: stacked,
                            //type: 'category',
                            scaleLabel: {
                                display: xscaleLabel,
                                labelString: xscaleLabelTxt
                            }
                        }],
                        yAxes: [{
                            stacked: stacked,
                            type: 'linear', // only linear but allow scale type registration. This allows extensions to exist solely for log scale for instance
                            display: true,
                            position: 'left',
                            id: 'y-axis-1',
                            ticks: {
                                suggestedMin: 0,
                            },
                            scaleLabel: {
                                display: y1scaleLabel,
                                labelString: y1scaleLabelTxt
                            }
                        },
                        {
                            type: 'linear', // only linear but allow scale type registration. This allows extensions to exist solely for log scale for instance
                            display: Y2axis, //
                            position: 'right',
                            id: 'y-axis-2',
                            gridLines: {
                                drawOnChartArea: Y2axis
                                },
                            ticks: {
                                suggestedMin: 0,
                                suggestedMax:100
                            },
                            scaleLabel: {
                                display: y2scaleLabel,
                                labelString: y2caleLabelTxt
                            }
                        }],
                    },
                    tooltips: VendorPortal_Chart.ChartToolTips(ctx)
                   };
                break
            case "horizontalBar" : 
                 options =
                    {
                    responsive: true,
                    elements: {
                        rectangle: {
                            borderWidth: 2,
                        }
                    },
                    legend: {
                        position: 'right',
                        display: true,
                        labels: {
                            fontColor: 'rgb(255, 99, 132)'
                        },
                        //onClick: newLegendClickHandler,
                        legendCallback: function (chart) {
                            // Return the HTML string here.
                        }
                    },
                    scales: {
                        xAxes: [{
                            stacked: stacked
                        }],
                        yAxes: [{
                            stacked: stacked
                        }]
                    },
                   tooltips: VendorPortal_Chart.ChartToolTips(ctx)
                };
                break
            case "pie":
                options = {
                    tooltips: VendorPortal_Chart.ChartToolTips(ctx)
                };
                break
            case "doughnut":
                options = {
                     tooltips: {
                        mode: 'index',
                        axis: 'x'
                    },
                };
                break
        }
        return options;
    },

    ChartToolTips: function (ctx) {
        return {
            // Disable the on-canvas tooltip
            enabled: false,
            mode: 'index',
            axis: 'x',
            custom: function (tooltipModel) {
                // Tooltip Element
                var tooltipEl = document.getElementById('chartjs-tooltip');

                // Create element on first render
                if (!tooltipEl) {
                    tooltipEl = document.createElement('div');
                    tooltipEl.id = 'chartjs-tooltip';
                    tooltipEl.innerHTML = '<table class="toolTipTable"></table>';
                    document.body.appendChild(tooltipEl);
                }

                // Hide if no tooltip
                if (tooltipModel.opacity === 0) {
                    tooltipEl.style.opacity = 0;
                    return;
                }

                // Set caret Position
                tooltipEl.classList.remove('above', 'below', 'no-transform');
                if (tooltipModel.yAlign) {
                    tooltipEl.classList.add(tooltipModel.yAlign);
                } else {
                    tooltipEl.classList.add('no-transform');
                }

                function getBody(bodyItem) {
                    return bodyItem.lines;
                }

                // Set Text
                if (tooltipModel.body) {
                    var titleLines = tooltipModel.title || [];
                    var bodyLines = tooltipModel.body.map(getBody);

                    var innerHtml = '<thead>';

                    titleLines.forEach(function (title) {
                        innerHtml += '<tr><th colspan="2">' + title + '</th></tr>';
                    });
                    innerHtml += '</thead><tbody>';

                    bodyLines.forEach(function (body, i) {
                        var colors = tooltipModel.labelColors[i];
                        var style = 'background:' + colors.backgroundColor;
                        style += '; border-color:' + colors.borderColor;
                        style += '; border-width: 1px';
                        var span = '<span style="' + style + '"></span>';
                        innerHtml += '<tr><td>' + span + body[0].split(":")[0] + '</td><td>' + body[0].split(":")[1] + '</td></tr>';
                    });
                    innerHtml += '</tbody>';

                    var tableRoot = tooltipEl.querySelector('table');
                    tableRoot.innerHTML = innerHtml;
                }
                // `this` will be the overall tooltip
                var position = this._chart.canvas.getBoundingClientRect();

                // Display, position, and set styles for font
                tooltipEl.style.opacity = 1;
                tooltipEl.style.position = 'absolute';
                tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
                tooltipEl.style.top = -150 + position.top + window.pageYOffset + tooltipModel.caretY + 'px';
                tooltipEl.style.fontFamily = tooltipModel._bodyFontFamily;
                tooltipEl.style.fontSize = tooltipModel.bodyFontSize + 'px';
                tooltipEl.style.fontStyle = tooltipModel._bodyFontStyle;
                tooltipEl.style.padding = 10 + tooltipModel.yPadding + 'px ' + tooltipModel.xPadding + 'px';
                tooltipEl.style.pointerEvents = 'none';
            }
        }
    },

    PlotTable: function (obj) {
        try {
            var tmpData = jQuery.grep(VendorPortal_Chart.data, function (d) { return (d.Name == obj); });
            _TableData = tmpData[0].TableData,  _TableColumns = tmpData[0].TableColumns;
            VendorPortal_Chart.InitContainer(obj, tmpData[0],"Table");
            tbl_obj = $('#tbl_' + obj).DataTable({
                data: _TableData,
                columns: _TableColumns,
                destroy: true,
                responsive: true,
                "ordering": false,
                "paging": false,
                "searching": false,
                scrollY: '30vh',
                scrollCollapse: true,
                "autoWidth": false,
                "info": false,
                "fnRowCallback": function (nRow, aData, iDisplayIndex) {
                    if (tmpData[0].Details)
                    $(nRow.cells[0]).parent().attr({
                        "ondblclick": "VendorPortal_Chart.GotoLink('" + aData[0] + "')", "title": "Please Double Click on the row for more details.", "style": "cursor:pointer",  });

                },
                "initComplete": function (settings, json) {
                }
            });
            new $.fn.dataTable.Buttons(tbl_obj, {
                buttons: [
                    {
                        extend: 'excel',
                        text: '<div class="ExportData"> <i class="fa fa-file-excel"></i></div>',
                        titleAttr: 'Export to Excel',
                        className: 'export',
                    },
                    {
                        extend: 'pdf',
                        text: '<div class="ExportData"> <i class="fa fa-file-pdf"></i></div>',
                        titleAttr: 'Export to PDF',
                        className: 'export',
                    },
                    {
                        extend: 'print',
                        text: '<div class="ExportData"> <i class="feather icon-printer"></i></div>',
                        titleAttr: 'Print',
                        className: 'export',
                    },
                ]
            });
            if (tmpData[0].Export)
                tbl_obj.buttons().container().prependTo($('#tbl_' + obj).parents(".card").children().children(".card-header-right"));
            if (tmpData[0].Default != "Table")
                $('#tbl_' + obj).parents(".card").children().children(".card-header-right").children(".dt-buttons").hide();

        } catch (err) {

        }
    },

    GotoLink: function (val) {
        window.open("http://google.com?id=" + val);
    },

}



var defaultLegendClickHandler = Chart.defaults.global.legend.onClick;
var newLegendClickHandler = function (e, legendItem) {
    var index = legendItem.datasetIndex;

    if (index > 1) {
        // Do the original logic
        defaultLegendClickHandler(e, legendItem);
    } else {
        let ci = this.chart;
        [
            ci.getDatasetMeta(0),
            ci.getDatasetMeta(1)
        ].forEach(function (meta) {
            meta.hidden = meta.hidden === null ? !ci.data.datasets[index].hidden : null;
        });
        ci.update();
    }
};

var DBConfig = [

{
        Name: "DealsNearClosure",
        Type: ["Table", ],
        Default: "Table",
        Caption: "Deals Near Closure",
        GraphType: ["horizontalBar"],
        Stacked: false,
        Export: true,
        Details: true,
        FirstTitle: "Deals",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
},
{
        Name: "LargestDinPipeline",
        Type: ["Table"],
        Default: "Table",
        Caption: "Largest Deals in Pipeline",
        GraphType: ["bar"],
        Stacked: false,
        Export: true,
        Details: true,
        FirstTitle: "Deals",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
},
{
        Name: "PerInitiatives",
        Type: ["Table"],
        Default: "Table",
        Caption: "Personel Initiatives",
        GraphType: ["doughnut"],
        Stacked: true,
        Export: true,
        Details: true,
        FirstTitle: "NAME OF INITIATIVE",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
},


{
        Name: "CurrPipeWinRate",
        Type: ["Table", "Chart"],
        Default: "Chart",
        Caption: "Current Pipeline value and Win Rate",
        GraphType: ["bar"],
        Stacked: true,
        Export: true,
        Details: false,
        FirstTitle: "Types",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
    },
{
        Name: "DealsLoss",
        Type: ["Table", "Chart"],
        Default: "Table",
        Caption: "Deal loss analysis",
        GraphType: ["bar"],
        Export: true,
        Stacked: true,
        Details: false,
        FirstTitle: "Types",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
    },
{
        Name: "DealsConversion",
        Type: ["Table", "Chart"],
        Default: "Chart",
        Caption: "Deal conversion report",
        GraphType: ["pie"],
        Export: true,
        Stacked: true,
        Details: false,
        FirstTitle: "Types",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
    },
{
        Name: "CurrBandwidth",
        Type: ["Table", "Chart"],
        Default: "Table",
        Caption: "Current bandwidth status",
        GraphType: ["bar"],
        Export: true,
        Stacked: true,
        Details: false,
        FirstTitle: "Types",
        Y2axis: false,
        Titles: [],
        dataSet: [],
        TableColumns: [],
        TableData: []
    },
]

