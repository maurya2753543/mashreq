var express = require('express');
var router = express.Router();
var botController = require('../controller/bot')
/* GET users listing. */

router.post('/message',botController.SendMessage)
router.get('/session',botController.createSession)

module.exports = router;
